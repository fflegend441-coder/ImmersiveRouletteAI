Immersive Roulette OCR Assistant — V5.1

V5.1 সংশোধন:
1. আগের নির্দিষ্ট 9.5%-13.5% crop বাদ। এখন স্ক্রিনের উপরের 32% থেকে OCR করে সবচেয়ে বেশি বৈধ 0-36 নম্বর থাকা horizontal line বেছে নেয়।
2. OCR line-এর element position ধরে বাম থেকে ডানে নম্বর সাজায়; প্রয়োজন হলে line-এর পূর্ণ text থেকেও fallback নেয়।
3. History-তে নতুন ফল বাম পাশে এলে overlap মিলিয়ে সর্বোচ্চ 8টি নতুন ফল শনাক্ত করতে পারে।
4. OCR ভুল/অমিল snapshot এলে সেটিকে visible history বা baseline হিসেবে ধরে না; ফলে ভুল OCR prediction-কে প্রভাবিত করে না।
5. European wheel-এর সঠিক pocket order ব্যবহার করে সাম্প্রতিক ফলের দুই পাশের sector-কে exponential recency weight দিয়ে rank করে। একই round-এ prediction স্থির থাকে; নতুন aligned result না এলে বদলায় না।
6. বর্তমান visible history-তে থাকা নম্বর এবং আগের prediction পরের candidate থেকে বাদ থাকে—এটি ব্যবহারকারীর পছন্দ অনুযায়ী, কিন্তু roulette-এ একই নম্বর আবার আসা সম্ভব।
7. History-তে অন্তত 12টি ফল না থাকলে prediction দেখায় না।

গুরুত্বপূর্ণ সীমাবদ্ধতা: European roulette-এ প্রতিটি spin স্বাধীন ও random। wheel-sector ranking কোনো প্রমাণিত winning strategy নয়, odds বাড়ায়—এমন নিশ্চয়তাও নেই। এটি কেবল history-ভিত্তিক heuristic ranking।

Project root-এ settings.gradle এবং app/ রয়েছে। GitHub Actions-এ Gradle 8.9 দিয়ে :app:assembleDebug চালানো যাবে।
