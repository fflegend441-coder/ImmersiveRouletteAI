Immersive Roulette AI V6.28 - Stable Round & Pattern Analysis

এই সংস্করণে:
- History row দুইটি স্থির OCR frame-এ নিশ্চিত হলে update গ্রহণ করে; আগের ৩-frame অপেক্ষা কমানো হয়েছে।
- স্বাভাবিক rolling overlap পাওয়া গেলে নতুন ফল শনাক্ত করে সঙ্গে সঙ্গে নতুন round calculation হয়।
- Overlap পাওয়া না গেলেও একই পরিবর্তিত row তিনবার স্থির থাকলে newest result দিয়ে history baseline update করে এবং নতুন calculation চালায়।
- এই fallback-এ আগের জমা history মুছে ফেলা হয় না।
- আগের prediction নম্বর wheel-এ আসা পর্যন্ত অপেক্ষা করার কোনো hit-condition নেই; নতুন ফল নিশ্চিত হলেই পুনরায় ranking হয়।
- একই round-এর history অপরিবর্তিত থাকলে prediction স্থির থাকে, যাতে একই round-এ বারবার flicker না করে।
- European wheel order, frequency, recency ও neighbour-sector heuristic রাখা হয়েছে।

গুরুত্বপূর্ণ: Roulette-এর প্রতিটি spin স্বাধীন। অতীতের ফল, wheel-neighbour বা frequency বিশ্লেষণ পরের ফল নিশ্চিতভাবে বলে না এবং জয়ের নিশ্চয়তা দেয় না।

GitHub Build:
1. ZIP Extract করুন।
2. Extract করা ফোল্ডারের ভেতরের build.gradle, settings.gradle, gradle.properties, app/ এবং .github/ ফাইল/ফোল্ডার repository root-এ upload/replace করুন।
3. ZIP ফাইলটি একা repository-তে upload করবেন না।
4. GitHub Actions-এ Android Build সফল হলে Artifacts থেকে APK ডাউনলোড করুন।

APK output: app/build/outputs/apk/debug/app-debug.apk

V6.22 - Per Round Prediction Refresh:
- প্রতিটি নতুন leftmost result দুইটি OCR read-এ নিশ্চিত হলেই নতুন round হিসেবে গ্রহণ করে।
- সম্পূর্ণ history row mismatch হলেও স্থির নতুন result শনাক্ত করে নতুন prediction calculation চালায়।
- আগের prediction নম্বর hit হওয়া পর্যন্ত অপেক্ষা করে না; প্রতি confirmed spin/round-এ নতুন prediction তৈরি করে।
- একই history row থাকলে prediction lock থাকে, যাতে একই round-এ অযথা prediction বদলায় না।


V6.24 Build identity / verification:
- Android app versionName 6.24, versionCode 26 করা হয়েছে।
- Floating panel heading-এ V6.24 দেখাবে, যাতে পুরোনো APK চালু আছে কি না বোঝা যায়।
- GitHub Actions artifact-এর নামও v6.24 করা হয়েছে।
- Repository root-এ ZIP-এর ভেতরের ফাইলগুলো extract করে replace করতে হবে; ZIP-টিকে একা upload করলে APK source update হবে না।
- Build সফল হওয়ার পর Actions > workflow run > Artifacts থেকে v6.24 APK নিতে হবে; পুরোনো APK uninstall করে নতুন APK install করতে হবে।


V6.24 সংশোধন:
- নতুন History-তে বামদিকের সর্বশেষ নম্বর বদলালে সেটি দুইটি স্থিতিশীল OCR snapshot-এ নিশ্চিত করা হয়।
- এই পরীক্ষা এক-সেল mismatch-এর early-return চেকের আগে চলে; ফলে নতুন ফলকে OCR noise ভেবে বাদ দিয়ে পুরোনো prediction lock আটকে থাকার ত্রুটি সংশোধন করা হয়েছে।
- আগের Prediction নম্বর আসা বাধ্যতামূলক নয়; প্রতিটি নিশ্চিত নতুন ফলের পর নতুন calculation চলে।


V6.26 update: Flow, Fast Break, Bracket, Zigzag এবং European wheel analysis যোগ করা হয়েছে। History scroll/re-sync/rebuild হলে সেটিকে নতুন spin ধরে prediction আর তৈরি করা হয় না; নতুন spin-এর confirmed rolling overlap না পাওয়া পর্যন্ত আগের prediction অপরিবর্তিত থাকে। Pattern analysis অতীত ফলের বর্ণনা, জয়ের নিশ্চয়তা নয়।


V6.28 সংশোধন:
- একই round-এর OCR row সামান্য বদলালেই prediction আর নতুন করে বদলাবে না; নতুন prediction-এর জন্য পুরোনো row-এর সঙ্গে verified rolling overlap দরকার।
- History re-sync, scroll বা rebuild-কে নতুন spin হিসেবে ধরা হয় না; এতে ভুল/হঠাৎ prediction দেখানোর ঝুঁকি কমে।
- আগের prediction নম্বরকে জোর করে বাদ দেওয়া বন্ধ; ইতিহাসের ranking অনুযায়ী একই নম্বর আবারও শীর্ষে আসতে পারে।
- Flow, Fast Break, Bracket, Zigzag এবং European wheel-neighbour/frequency/recency বিশ্লেষণ রাখা হয়েছে।
- Build identity V6.28 / versionCode 29।

সীমাবদ্ধতা: OCR নির্ভরতা ও গেমের history strip-এর বিন্যাসের কারণে ভুল শনাক্তকরণ পুরোপুরি অসম্ভব করা যায় না। Roulette-এর প্রতিটি spin স্বাধীন; কোনো sequence বা strategy পরের ফল নিশ্চিতভাবে বলতে পারে না।
