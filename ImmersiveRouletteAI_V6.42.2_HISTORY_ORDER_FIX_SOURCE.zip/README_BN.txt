ImmersiveRouletteAI V6.42.2 — Source ZIP

এই সংস্করণে V6.40-এর কোডের ওপর বাস্তব সংশোধন:
1) Wheel analysis-এর জন্য source frame আর জোর করে 160x240-এ stretch করা হয় না; aspect ratio বজায় রেখে letterbox করা হয়।
2) একটি brightest pixel-কে Ball ধরে নেওয়ার বদলে 72টি angular sector-এ কাছাকাছি bright/temporal pixel group করা হয়; অন্তত 3টি pixel না থাকলে candidate গ্রহণ করা হয় না।
3) আগের angle-এর কাছাকাছি coherent sector-কে অগ্রাধিকার দেওয়া হয়; সর্বোচ্চ angular jump 65 degree করা হয়েছে।
4) Tracker diagnostics সাম্প্রতিক OCR status-কে overwrite করে না।
5) App version 6.42.2 / versionCode 43 এবং GitHub Actions artifact name মিলানো হয়েছে।
6) History strip newest-at-right হলে নতুন ফলের insertion order সংশোধন করা হয়েছে।
7) Wheel/Ball tracker experimental; এটি calibrated ball detector নয় এবং live-game accuracy যাচাই করা হয়নি।

যা এখনো সম্পূর্ণ নয়:
- এটি trained ball object detector নয়; bright moving feature candidate মাত্র। Reflection/lighting-কে Ball হিসেবে ভুল ধরতে পারে।
- wheel rim localization এখনো heuristic; calibrated camera-angle classifier নয়।
- Ball ও wheel-এর প্রকৃত physical speed/landing point হিসাব করা হয় না।
- Adaptive OCR এখনো screen-এর upper region-এ contrast band নির্বাচন করে; সব 1xBet layout-এ validated নয়।
- পূর্ণ Android APK build এই environment-এ চালানো যায়নি, কারণ Android SDK/Gradle installation নেই।

Build: GitHub Actions-এ push বা workflow_dispatch চালিয়ে app-debug.apk তৈরি করুন।
Roulette outcome independent/random; এই অ্যাপ নিশ্চিত prediction বা লাভের নিশ্চয়তা দেয় না।
