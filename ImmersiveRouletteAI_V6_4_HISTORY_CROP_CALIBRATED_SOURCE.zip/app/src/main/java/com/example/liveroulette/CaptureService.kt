package com.example.liveroulette

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import kotlin.math.abs

class CaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "roulette_ocr_capture"
        private const val NOTIFICATION_ID = 7102
        private const val ACTION_STOP = MainActivity.ACTION_STOP
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var predictionView: TextView? = null
    private var statusView: TextView? = null
    private var starButton: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null

    @Volatile private var scanActive = false
    @Volatile private var processing = false
    private var lastOcrAt = 0L
    private var pendingNumbers: List<Int> = emptyList()
    private var pendingRepeats = 0
    private var mismatchSnapshot: List<Int> = emptyList()
    private var mismatchRepeats = 0
    // The game strip is newest-first (left to right) on the supplied game screen.
    private var previousNumbers: List<Int> = emptyList()
    private var visibleHistory: List<Int> = emptyList()
    private var lastPrediction: Int? = null
    private val recentHistory = ArrayDeque<Int>()
    private val historyPrefs by lazy { getSharedPreferences("roulette_history", Context.MODE_PRIVATE) }
    private val numberRegex = Regex("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)")

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadSavedHistory()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        if (projection == null) {
            val resultCode = intent?.getIntExtra(MainActivity.EXTRA_RESULT_CODE, 0) ?: 0
            val resultData = intent?.getParcelableExtra<Intent>(MainActivity.EXTRA_RESULT_DATA)
            if (resultCode == 0 || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            startProjection(resultCode, resultData)
            showPanel()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)
        scanActive = false

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        workerThread = HandlerThread("RouletteOCRWorker").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)

        // Android 14+ requires the callback to be registered before the first
        // VirtualDisplay is created for this MediaProjection session.
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                scanActive = false
                stopSelf()
            }
        }, workerHandler)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                try {
                    if (scanActive && !processing && System.currentTimeMillis() - lastOcrAt >= 650L) {
                        lastOcrAt = System.currentTimeMillis()
                        processImage(image)
                    }
                } finally {
                    image.close()
                }
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "RouletteOCRDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            // Do not capture the screen until the user explicitly enables STAR.
            null,
            null,
            workerHandler
        )

        updateStatus("STAR OFF • চালু করতে STAR চাপুন")
    }

    private fun processImage(image: Image) {
        if (!scanActive || processing) return

        // The live results strip is at the top of the supplied portrait game
        // layout. OCR only this narrow region instead of mixing in the betting
        // grid, balance, timer, and other unrelated screen numbers.
        val fullBitmap = imageToBitmap(image) ?: return
        val historyBitmap = cropHistoryStrip(fullBitmap)
        if (historyBitmap == null) {
            fullBitmap.recycle()
            updateStatus("History strip crop করা যায়নি")
            return
        }

        processing = true
        recognizer.process(InputImage.fromBitmap(historyBitmap, 0))
            .addOnSuccessListener { result ->
                if (!scanActive) return@addOnSuccessListener
                val numbers = extractHistoryNumbers(result)
                if (numbers.size in 10..15) {
                    registerHistorySnapshot(numbers)
                } else {
                    pendingNumbers = emptyList()
                    pendingRepeats = 0
                    updateStatus("উপরের History Row পড়া যাচ্ছে না")
                }
            }
            .addOnFailureListener {
                updateStatus("OCR পড়তে সমস্যা হচ্ছে • আবার চেষ্টা করছি")
            }
            .addOnCompleteListener {
                processing = false
                if (!historyBitmap.isRecycled) historyBitmap.recycle()
                if (!fullBitmap.isRecycled) fullBitmap.recycle()
            }
    }

    /**
     * Crop the top results strip from the supplied portrait game screen.
     * Calibrated from the supplied 675x1500 game screenshot: the history
     * cells occupy about y=162..196 (10.8%-13.1%). Keep a narrow margin
     * while excluding the roulette video and the table below the strip.
     */
    private fun cropHistoryStrip(source: Bitmap): Bitmap? {
        return try {
            if (source.width < 200 || source.height < 400) return null
            val top = (source.height * 0.105f).toInt().coerceIn(0, source.height - 2)
            val bottom = (source.height * 0.135f).toInt().coerceIn(top + 1, source.height)
            val strip = Bitmap.createBitmap(source, 0, top, source.width, bottom - top)
            val scaled = Bitmap.createScaledBitmap(
                strip,
                (strip.width * 2).coerceAtMost(2400),
                (strip.height * 2).coerceAtMost(500),
                true
            )
            if (scaled !== strip) strip.recycle()
            scaled
        } catch (_: Exception) {
            null
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Reconstruct horizontal OCR rows from word boxes. The live game normally
     * exposes 13 recent results in one strip; betting-grid rows have only three
     * values, while the expanded 500-result statistics view is a different layout.
     * Ambiguous rows are rejected instead of guessing from an arbitrary screen row.
     */
    private fun extractHistoryNumbers(result: Text): List<Int> {
        data class Token(val value: Int, val left: Int, val centerY: Int, val top: Int, val bottom: Int)
        data class Candidate(val values: List<Int>, val top: Int, val width: Int)

        val tokens = mutableListOf<Token>()
        val singleCellPattern = Regex("(?:[0-9]|[12][0-9]|3[0-6])")
        // ML Kit sometimes returns the full history as one line but also emits
        // unusable element boxes. Always fall back to the line text when fewer
        // than 10 valid number cells were recovered from its elements.
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val lineBox = line.boundingBox ?: continue
                val elementTokens = mutableListOf<Token>()
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    val raw = element.text.trim().uppercase()
                    // Correct common single-character OCR confusions in short cells only.
                    val normalized = if (raw.length <= 2) raw
                        .replace('O', '0').replace('Q', '0')
                        .replace('I', '1').replace('L', '1')
                        .replace('|', '1').replace('S', '5').replace('B', '8')
                    else raw
                    if (!singleCellPattern.matches(normalized)) continue
                    val value = normalized.toIntOrNull() ?: continue
                    if (value in 0..36) {
                        elementTokens += Token(value, box.left, box.centerY(), box.top, box.bottom)
                    }
                }
                if (elementTokens.size in 10..15) {
                    tokens.addAll(elementTokens)
                    continue
                }

                // Fallback is intentionally line-scoped: it cannot accidentally
                // mix the betting grid or balance with the History strip crop.
                val matches = numberRegex.findAll(line.text).toList()
                val values = matches.mapNotNull { it.value.toIntOrNull() }.filter { it in 0..36 }
                if (values.size in 10..15) {
                    values.forEachIndexed { index, value ->
                        val match = matches[index]
                        val estimatedLeft = lineBox.left +
                            (lineBox.width() * match.range.first / line.text.length.coerceAtLeast(1))
                        tokens += Token(value, estimatedLeft, lineBox.centerY(), lineBox.top, lineBox.bottom)
                    }
                }
            }
        }
        if (tokens.size < 10) return emptyList()

        val typicalHeight = tokens.map { (it.bottom - it.top).coerceAtLeast(1) }.sorted()
            .let { it[it.size / 2] }
        val rowTolerance = maxOf(7, (typicalHeight * 0.70f).toInt())
        val rows = mutableListOf<MutableList<Token>>()
        for (token in tokens.sortedBy { it.centerY }) {
            val row = rows.minByOrNull { group ->
                abs(group.map { it.centerY }.average() - token.centerY)
            }
            if (row != null && abs(row.map { it.centerY }.average() - token.centerY) <= rowTolerance) {
                row += token
            } else {
                rows += mutableListOf(token)
            }
        }

        val candidates = rows.mapNotNull { row ->
            val ordered = row.sortedBy { it.left }
            val values = ordered.map { it.value }
            if (values.size !in 10..15) null
            else Candidate(values, ordered.minOf { it.top }, ordered.last().left - ordered.first().left)
        }.sortedWith(
            compareBy<Candidate> { abs(it.values.size - 13) }
                .thenByDescending { it.width }
                .thenBy { it.top }
        )

        val best = candidates.firstOrNull() ?: return emptyList()
        val second = candidates.getOrNull(1)
        if (second != null && abs(second.values.size - 13) == abs(best.values.size - 13) &&
            second.width >= (best.width * 0.85f).toInt()) return emptyList()
        return best.values
    }

    private fun loadSavedHistory() {
        val saved = historyPrefs.getString("numbers", "").orEmpty()
            .split(',').mapNotNull { it.toIntOrNull() }.filter { it in 0..36 }.take(100)
        recentHistory.clear()
        saved.forEach { recentHistory.addLast(it) }

        // Persist the exact visible strip separately. Taking an arbitrary 13
        // values from the longer history can create a false "new spin" after
        // restart when the live strip contains 14 or another supported count.
        val baseline = historyPrefs.getString("visible_baseline", "").orEmpty()
            .split(',').mapNotNull { it.toIntOrNull() }.filter { it in 0..36 }
        if (baseline.size in 10..15) {
            previousNumbers = baseline
            visibleHistory = baseline
        }
    }

    private fun saveHistory() {
        historyPrefs.edit()
            .putString("numbers", recentHistory.joinToString(","))
            .putString("visible_baseline", previousNumbers.joinToString(","))
            .apply()
    }

    private fun registerHistorySnapshot(numbers: List<Int>) {
        val stableWithPrevious = numbers == pendingNumbers ||
            (numbers.size == pendingNumbers.size &&
                pendingNumbers.isNotEmpty() && sequenceEditDistance(numbers, pendingNumbers) <= 2)
        if (stableWithPrevious) {
            pendingRepeats++
        } else {
            pendingNumbers = numbers
            pendingRepeats = 1
        }
        if (pendingRepeats < 3) return

        if (previousNumbers.isEmpty()) {
            // First scan after an older app version or cleared baseline: use the
            // current strip as the alignment anchor. Preserve already-saved
            // accumulated history to avoid throwing away valid older results.
            previousNumbers = numbers
            visibleHistory = numbers
            if (recentHistory.isEmpty()) {
                numbers.forEach { recentHistory.addLast(it) }
            }
            saveHistory()
            updatePredictionFromHistory("History loaded • ${numbers.size} results")
            return
        }

        // Treat a near-identical strip as the same round with OCR noise.
        // Without this guard, edit-distance alignment can mistake the natural
        // one-cell shift of an unchanged row for a newly arrived result.
        if (numbers.size == previousNumbers.size &&
            numbers.zip(previousNumbers).count { (current, previous) -> current != previous } <= 2
        ) {
            mismatchSnapshot = emptyList()
            mismatchRepeats = 0
            visibleHistory = numbers
            // Refresh the baseline with the latest clean OCR reading so small
            // character corrections do not poison the next round comparison.
            previousNumbers = numbers
            saveHistory()
            if (lastPrediction == null && recentHistory.size >= 12) {
                updatePredictionFromHistory("History restored • ${recentHistory.size} results")
            }
            return
        }

        val newResults = findNewResults(previousNumbers, numbers)

        if (newResults.isNotEmpty()) {
            mismatchSnapshot = emptyList()
            mismatchRepeats = 0
            visibleHistory = numbers
            // Leftmost values are newest. Insert the detected values in newest-first order.
            newResults.asReversed().forEach { recentHistory.addFirst(it) }
            while (recentHistory.size > 100) recentHistory.removeLast()
            previousNumbers = numbers
            saveHistory()
            updatePredictionFromHistory("নতুন ফল • ${recentHistory.size} results")
        } else {
            // Do not stay stuck forever on an obsolete saved baseline (for
            // example after a table/session reset). Require the same valid strip
            // repeatedly before safely re-baselining; do not count it as a new spin.
            if (mismatchSnapshot.isNotEmpty() &&
                sequenceEditDistance(numbers, mismatchSnapshot) <= 2
            ) {
                mismatchRepeats++
                mismatchSnapshot = numbers
            } else {
                mismatchSnapshot = numbers
                mismatchRepeats = 1
            }

            if (mismatchRepeats >= 5) {
                previousNumbers = numbers
                visibleHistory = numbers
                // The old saved baseline no longer matches this table/session.
                // Rebuild the working history from the confirmed live strip;
                // otherwise prediction keeps calculating against stale rounds.
                recentHistory.clear()
                numbers.forEach { recentHistory.addLast(it) }
                saveHistory()
                mismatchSnapshot = emptyList()
                mismatchRepeats = 0
                updatePredictionFromHistory("History নতুন করে Sync হয়েছে • ${numbers.size} results")
            } else {
                updateStatus("History মিলছে না • Sync ${mismatchRepeats}/5")
            }
        }
    }

    /**
     * New results enter at the LEFT. Compare old[0...] with current[shift...]
     * using edit distance, so one missed/duplicated OCR token does not break
     * the entire history alignment. Ambiguous or weak matches are rejected.
     */
    private fun findNewResults(old: List<Int>, current: List<Int>): List<Int> {
        if (old.size < 6 || current.size < 6) return emptyList()
        val maxShift = minOf(12, current.size - 6)
        if (maxShift < 1) return emptyList()

        data class Match(val shift: Int, val similarity: Double, val edits: Int)
        val matches = mutableListOf<Match>()

        for (shift in 1..maxShift) {
            val oldPart = old.take(minOf(old.size, current.size - shift))
            val currentPart = current.drop(shift).take(oldPart.size)
            if (oldPart.size < 6 || currentPart.size < 6) continue
            val edits = sequenceEditDistance(oldPart, currentPart)
            val similarity = 1.0 - edits.toDouble() / maxOf(oldPart.size, currentPart.size)
            if (similarity >= 0.72 && edits <= 3) {
                matches += Match(shift, similarity, edits)
            }
        }

        if (matches.isEmpty()) return emptyList()
        val ranked = matches.sortedWith(
            compareByDescending<Match> { it.similarity }
                .thenBy { it.edits }
                .thenBy { it.shift }
        )
        val best = ranked.first()
        // If two different shifts fit almost equally well, wait for a cleaner OCR frame.
        val runnerUp = ranked.getOrNull(1)
        if (runnerUp != null && best.similarity - runnerUp.similarity < 0.035) {
            return emptyList()
        }
        return current.take(best.shift)
    }

    private fun sequenceEditDistance(a: List<Int>, b: List<Int>): Int {
        var previous = IntArray(b.size + 1) { it }
        for (i in 1..a.size) {
            val current = IntArray(b.size + 1)
            current[0] = i
            for (j in 1..b.size) {
                val substitution = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val deletion = previous[j] + 1
                val insertion = current[j - 1] + 1
                current[j] = minOf(substitution, deletion, insertion)
            }
            previous = current
        }
        return previous[b.size]
    }

    private fun updatePredictionFromHistory(status: String) {
        // Do not manufacture a guess from a tiny sample. The visible history row
        // normally supplies enough results immediately after OCR stabilizes.
        if (recentHistory.size < 12) {
            lastPrediction = null
            updatePrediction(null)
            updateStatus("আরও History দরকার • ${recentHistory.size}/12")
            return
        }
        val next = chooseHistoryBasedGuess()
        lastPrediction = next
        updatePrediction(next)
        updateStatus("$status • History বিশ্লেষণ সম্পন্ন")
    }

    /**
     * Rank numbers outside the currently visible history by their proximity to
     * recent results on the European wheel. This is only a sector heuristic:
     * independent roulette spins do not become predictable from past results.
     */
    private fun chooseHistoryBasedGuess(): Int {
        val wheel = listOf(
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13,
            36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14,
            31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
        )
        val history = recentHistory.toList().take(60) // newest first
        // Any European pocket can repeat on the next independent spin.
        // Never exclude numbers merely because they appeared in recent history.
        val candidates = (0..36).toList()
        if (candidates.isEmpty()) return (0..36).firstOrNull { it != lastPrediction } ?: 0

        // Recent spins receive exponentially greater weight. For each result,
        // score the neighbouring European-wheel pockets (not the result itself).
        val scores = DoubleArray(37)
        history.forEachIndexed { historyIndex, result ->
            val wheelIndex = wheel.indexOf(result)
            if (wheelIndex < 0) return@forEachIndexed
            val recencyWeight = kotlin.math.exp(-historyIndex.toDouble() / 12.0)
            for (offset in -4..4) {
                val distance = abs(offset)
                if (distance == 0) continue
                val candidate = wheel[(wheelIndex + offset + wheel.size) % wheel.size]
                if (candidate in candidates) {
                    val sectorWeight = (5 - distance).toDouble()
                    scores[candidate] += recencyWeight * sectorWeight
                }
            }
        }

        // Deterministic tie-break: do not jump randomly while the same round is active.
        return candidates.maxWithOrNull(
            compareBy<Int> { scores[it] }.thenBy { -it }
        ) ?: candidates.first()
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(14, 48, 65), Color.rgb(16, 120, 91), Color.rgb(8, 30, 45))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.rgb(75, 230, 177))
            }
        }
        val heading = TextView(this).apply {
            text = "ROULETTE"
            setTextColor(Color.WHITE)
            textSize = 7f
            gravity = Gravity.CENTER
        }
        predictionView = TextView(this).apply {
            text = "--"
            setTextColor(Color.rgb(91, 255, 145))
            textSize = 27f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        statusView = TextView(this).apply {
            text = "STAR OFF"
            setTextColor(Color.WHITE)
            textSize = 7f
            gravity = Gravity.CENTER
            maxLines = 2
        }
        starButton = TextView(this).apply {
            text = "☆ STAR"
            setTextColor(Color.WHITE)
            textSize = 9f
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(7), dp(3), dp(7), dp(3))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(10).toFloat()
                setColor(Color.rgb(30, 75, 85))
                setStroke(dp(1), Color.rgb(90, 220, 180))
            }
            setOnClickListener {
                scanActive = !scanActive
                pendingNumbers = emptyList()
                pendingRepeats = 0
                mismatchSnapshot = emptyList()
                mismatchRepeats = 0
                // Detach the capture surface while paused so frames are not
                // delivered to the OCR pipeline until the user enables STAR.
                virtualDisplay?.setSurface(if (scanActive) imageReader?.surface else null)
                if (scanActive) {
                    updatePrediction(null)
                    updateStatus("গেম History খুঁজছি…")
                    text = "★ STAR ON"
                } else {
                    updateStatus("SCAN PAUSED")
                    text = "☆ STAR OFF"
                }
            }
        }

        root.addView(heading, LinearLayout.LayoutParams(dp(82), dp(12)))
        root.addView(predictionView, LinearLayout.LayoutParams(dp(82), dp(39)))
        root.addView(statusView, LinearLayout.LayoutParams(dp(82), dp(18)))
        root.addView(starButton, LinearLayout.LayoutParams(dp(68), dp(22)))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val panelSize = dp(104)
        panelParams = WindowManager.LayoutParams(
            panelSize,
            panelSize,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Keep the floating panel below the live History strip. The old
            // y=140px default covered the leftmost history cells on this game.
            x = 12
            y = 270
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val params = panelParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })

        try {
            windowManager.addView(root, panelParams)
            panel = root
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun updatePrediction(number: Int?) {
        android.os.Handler(mainLooper).post {
            predictionView?.text = number?.toString() ?: "--"
        }
    }

    private fun updateStatus(message: String) {
        android.os.Handler(mainLooper).post {
            statusView?.text = message
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Roulette OCR capture",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scanActive = false
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
