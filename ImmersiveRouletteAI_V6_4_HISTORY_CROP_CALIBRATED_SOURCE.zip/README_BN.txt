Immersive Roulette AI - Version 6.4 source

Version 6.4 source corrections:
1. OCR is restricted to the top live History strip region shown in the supplied portrait screenshot (normalized y=9.5%-14.2%), then enlarged 2x before ML Kit recognition. Betting-grid numbers and unrelated screen text are no longer considered.
2. A valid 10-15 number horizontal History row is required. If it cannot be read, no result is added.
3. Stable OCR snapshots tolerate up to two character/number recognition differences; history alignment tolerates up to three edit operations while retaining a strong sequence-overlap threshold.
4. If a valid but unaligned History row persists for five stable scans, the app safely re-syncs its baseline without counting the row as a new spin. This prevents permanent "History মিলছে না" lock-up.
5. The exact visible History baseline is persisted separately from accumulated history. This prevents a false duplicate spin after app restart when the live strip contains 14 values (or another supported 10-15 count).
6. STAR OFF starts with the VirtualDisplay surface detached. STAR ON attaches the ImageReader surface; STAR OFF detaches it again. OCR runs only while STAR is on.
7. Existing European wheel sector heuristic is retained. Roulette outcomes are independent; the displayed number is a statistical heuristic, not a guaranteed prediction.

Important:
- The crop is tuned to the supplied portrait Immersive Roulette screenshot. If the casino app changes its top layout or is used in landscape/zoom mode, the crop coordinates may need adjustment.
- This environment does not have Android SDK/Gradle installed, so an APK build could not be run here. Please build with the included GitHub Actions workflow or Android Studio, then test on the actual phone.

V6.4: সরবরাহ করা 675x1500 স্ক্রিনশট অনুযায়ী History Row crop y=10.5%-13.5% এ সংকুচিত করা হয়েছে।
