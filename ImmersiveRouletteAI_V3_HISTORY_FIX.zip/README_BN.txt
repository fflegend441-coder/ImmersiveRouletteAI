নতুন Immersive Roulette AI OCR project (version 3.0)

কী পরিবর্তন হয়েছে:
1. OCR এখন পুরো betting table থেকে নম্বর বেছে নেয় না; supplied game screenshot অনুযায়ী উপরের horizontal history strip crop করে পড়ে।
2. ০-৩৬ নম্বরের মধ্যে অন্তত ৬টি history value না পেলে OCR result গ্রহণ করে না, তাই betting grid-এর ১/২-কে history result ধরে নেওয়ার ঝুঁকি কমে।
3. একই history row দুইবার স্থিরভাবে পড়ার পরই গ্রহণ করে।
4. নতুন round এলে শুধু নতুন যোগ হওয়া result history-তে যোগ হয়; পুরোনো ১৪টি result বারবার যোগ হয় না।
5. বর্তমান visible game-history-তে থাকা নম্বর prediction থেকে বাদ থাকে; আগের prediction-ও পরেরবার বাদ থাকে।
6. নতুন history result শনাক্ত হলেই prediction update হয়, তাই timer হলুদ হওয়ার জন্য অপেক্ষা করে না।
7. STAR OFF থাকলে OCR/বিশ্লেষণ চলে না।

Build:
GitHub Actions workflow-এ ZIP extract করে source project root-এ gradle assembleDebug চালাতে হবে। ZIP-এর root-এ settings.gradle এবং app/ folder থাকবে।

সতর্কতা: Roulette random. Prediction কেবল history-ভিত্তিক heuristic; পরের ফল নিশ্চিতভাবে বলা যায় না।

OCR crop supplied game screenshot-এর top history strip layout অনুযায়ী নির্ধারিত। গেমের layout/স্ক্রিন scaling বদলালে crop position সামঞ্জস্য করতে হতে পারে।
