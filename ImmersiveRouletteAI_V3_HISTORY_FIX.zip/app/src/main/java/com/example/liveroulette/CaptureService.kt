package com.example.liveroulette

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import kotlin.math.abs

class CaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "roulette_ocr_capture"
        private const val NOTIFICATION_ID = 7102
        private const val ACTION_STOP = MainActivity.ACTION_STOP
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var predictionView: TextView? = null
    private var statusView: TextView? = null
    private var starButton: Button? = null
    private var panelParams: WindowManager.LayoutParams? = null

    @Volatile private var starActive = false
    @Volatile private var processing = false
    private var lastOcrAt = 0L
    private var pendingNumbers: List<Int> = emptyList()
    private var pendingRepeats = 0
    // The game strip is newest-first (left to right) on the supplied game screen.
    private var previousNumbers: List<Int> = emptyList()
    private var visibleHistory: List<Int> = emptyList()
    private var lastPrediction: Int? = null
    private val recentHistory = ArrayDeque<Int>()
    private val numberRegex = Regex("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)")

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        if (projection == null) {
            val resultCode = intent?.getIntExtra(MainActivity.EXTRA_RESULT_CODE, 0) ?: 0
            val resultData = intent?.getParcelableExtra<Intent>(MainActivity.EXTRA_RESULT_DATA)
            if (resultCode == 0 || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            startProjection(resultCode, resultData)
            showPanel()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        workerThread = HandlerThread("RouletteOCRWorker").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                try {
                    if (starActive && !processing && System.currentTimeMillis() - lastOcrAt >= 500L) {
                        lastOcrAt = System.currentTimeMillis()
                        processImage(image)
                    }
                } finally {
                    image.close()
                }
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "RouletteOCRDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, workerHandler)
    }

    private fun processImage(image: Image) {
        val fullBitmap = imageToBitmap(image) ?: return
        val historyBitmap = cropHistoryStrip(fullBitmap)
        fullBitmap.recycle()
        if (historyBitmap == null) {
            updateStatus("History strip পাওয়া যায়নি")
            return
        }

        processing = true
        recognizer.process(InputImage.fromBitmap(historyBitmap, 0))
            .addOnSuccessListener { result ->
                if (!starActive) return@addOnSuccessListener
                val numbers = extractHistoryNumbers(result)
                // The history strip normally contains about 14 values. Reject short
                // OCR fragments so betting-table numbers such as 1 or 2 are not used.
                if (numbers.size in 6..20) {
                    registerHistorySnapshot(numbers)
                } else {
                    pendingNumbers = emptyList()
                    pendingRepeats = 0
                    updateStatus("History row পড়া যাচ্ছে না • গেম স্ক্রিন দেখান")
                }
            }
            .addOnFailureListener {
                updateStatus("OCR পড়তে সমস্যা হচ্ছে")
            }
            .addOnCompleteListener {
                processing = false
                if (!historyBitmap.isRecycled) historyBitmap.recycle()
            }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        } catch (_: Exception) {
            null
        }
    }

    /**
     * The supplied game screenshot places its horizontal result-history strip
     * immediately below the top balance/header (roughly 9.5%-13.5% of screen height).
     * OCR is restricted to this strip, not the 0-36 betting grid below it.
     */
    private fun cropHistoryStrip(source: Bitmap): Bitmap? {
        return try {
            val top = (source.height * 0.095f).toInt().coerceIn(0, source.height - 1)
            val bottom = (source.height * 0.135f).toInt().coerceIn(top + 1, source.height)
            val strip = Bitmap.createBitmap(source, 0, top, source.width, bottom - top)
            val enlarged = Bitmap.createScaledBitmap(strip, strip.width * 2, strip.height * 2, true)
            strip.recycle()
            enlarged
        } catch (_: Exception) {
            null
        }
    }

    private fun extractHistoryNumbers(result: Text): List<Int> {
        val bestLine = result.textBlocks
            .flatMap { it.lines }
            .maxByOrNull { line -> numberRegex.findAll(line.text).count() }
            ?: return emptyList()

        // Use left-to-right element positions so the history order remains stable.
        val fromElements = bestLine.elements
            .sortedBy { it.boundingBox?.left ?: Int.MAX_VALUE }
            .flatMap { element -> numberRegex.findAll(element.text).mapNotNull { it.value.toIntOrNull() }.toList() }
            .filter { it in 0..36 }

        val parsed = if (fromElements.size >= 6) {
            fromElements
        } else {
            numberRegex.findAll(bestLine.text).mapNotNull { it.value.toIntOrNull() }
                .filter { it in 0..36 }.toList()
        }
        return parsed.take(20)
    }

    private fun registerHistorySnapshot(numbers: List<Int>) {
        if (numbers == pendingNumbers) {
            pendingRepeats++
        } else {
            pendingNumbers = numbers
            pendingRepeats = 1
        }
        if (pendingRepeats < 2) return

        if (previousNumbers.isEmpty()) {
            previousNumbers = numbers
            visibleHistory = numbers
            recentHistory.clear()
            numbers.forEach { recentHistory.addLast(it) }
            updatePredictionFromHistory("History loaded • ${numbers.size} results")
            return
        }

        if (numbers == previousNumbers) return

        val newResults = findNewResults(previousNumbers, numbers)
        previousNumbers = numbers
        visibleHistory = numbers

        if (newResults.isNotEmpty()) {
            // newResults are newest-first; add them in reverse to keep deque newest-first.
            newResults.asReversed().forEach { recentHistory.addFirst(it) }
            while (recentHistory.size > 100) recentHistory.removeLast()
            updatePredictionFromHistory("New round detected • ${recentHistory.size} results")
        } else {
            updateStatus("History changed • নতুন ফল যাচাই হচ্ছে")
        }
    }

    /**
     * Find the newly inserted values by matching the old newest-first row against
     * the shifted tail of the new row. This prevents re-adding all 14 visible values
     * every time one spin is added.
     */
    private fun findNewResults(old: List<Int>, current: List<Int>): List<Int> {
        var bestShift = 0
        var bestOverlap = 0
        val maxShift = minOf(4, current.size - 5)
        for (shift in 1..maxShift) {
            val overlap = minOf(old.size, current.size - shift)
            if (overlap >= 5 && overlap > bestOverlap &&
                old.take(overlap) == current.drop(shift).take(overlap)
            ) {
                bestShift = shift
                bestOverlap = overlap
            }
        }
        val requiredOverlap = maxOf(5, minOf(old.size, current.size) - 3)
        return if (bestShift > 0 && bestOverlap >= requiredOverlap) current.take(bestShift) else emptyList()
    }

    private fun updatePredictionFromHistory(status: String) {
        val next = chooseLowFrequencyGuess()
        lastPrediction = next
        updatePrediction(next)
        updateStatus("$status • Betting close-এর আগেই প্রস্তুত")
    }

    private fun chooseLowFrequencyGuess(): Int {
        val counts = IntArray(37)
        recentHistory.forEach { if (it in 0..36) counts[it]++ }
        val excluded = visibleHistory.toSet()
        var candidates = (0..36).filter { it !in excluded && it != lastPrediction }
        if (candidates.isEmpty()) candidates = (0..36).filter { it != lastPrediction }
        if (candidates.isEmpty()) candidates = (0..36).toList()

        val minimum = candidates.minOf { counts[it] }
        val leastSeen = candidates.filter { counts[it] == minimum }
        // Rotate ties from the current history signature so the app does not keep
        // selecting the first numeric value on every round.
        val signature = visibleHistory.fold(17L) { acc, value -> (acc * 31L + value) and Long.MAX_VALUE }
        val index = (signature % leastSeen.size.toLong()).toInt()
        return leastSeen[index]
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.argb(235, 25, 25, 25))
        }
        val heading = TextView(this).apply {
            text = "ROULETTE AI"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        predictionView = TextView(this).apply {
            text = "--"
            setTextColor(Color.GREEN)
            textSize = 42f
            gravity = Gravity.CENTER
            setPadding(10, 2, 10, 2)
        }
        statusView = TextView(this).apply {
            text = "STAR OFF • OCR বন্ধ"
            setTextColor(Color.LTGRAY)
            textSize = 11f
            gravity = Gravity.CENTER
        }
        starButton = Button(this).apply {
            text = "★ STAR OFF"
            setOnClickListener {
                starActive = !starActive
                text = if (starActive) "★ STAR ON" else "★ STAR OFF"
                updateStatus(if (starActive) "OCR চালু • Roulette screen দেখান" else "STAR OFF • OCR বন্ধ")
            }
        }
        val closeButton = Button(this).apply {
            text = "CLOSE PANEL"
            setOnClickListener { stopSelf() }
        }
        root.addView(heading)
        root.addView(predictionView)
        root.addView(statusView)
        root.addView(starButton)
        root.addView(closeButton)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val params = panelParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(root, panelParams)
            panel = root
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun updatePrediction(number: Int) {
        android.os.Handler(mainLooper).post {
            predictionView?.text = number.toString()
        }
    }

    private fun updateStatus(message: String) {
        android.os.Handler(mainLooper).post {
            statusView?.text = message
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Roulette OCR capture",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        starActive = false
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
