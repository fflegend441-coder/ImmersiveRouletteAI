package com.example.liveroulette

fun main() {
    fun sig(value: Int) = IntArray(576) { value }
    val d = CameraSceneDetector()
    check(!d.update(sig(20)).cutDetected)
    // settle initial view (3 stable comparisons after warm-up)
    d.update(sig(20)); d.update(sig(20)); d.update(sig(20))
    check(d.update(sig(220)).let { it.cutDetected && it.sceneId == 2 && !it.stable })
    // A second cut only 100 ms later must not be hidden by a cooldown.
    check(d.update(sig(40)).let { it.cutDetected && it.sceneId == 3 && !it.stable })
    d.update(sig(40))
    d.update(sig(40))
    check(d.update(sig(40)).stable)
    // Ordinary moderate motion after ready must not mark scene unready.
    val moving = IntArray(576) { if (it % 2 == 0) 55 else 25 }
    check(d.update(moving).let { !it.cutDetected && it.stable })
    // A further rapid transition after stability is detected.
    check(d.update(sig(210)).let { it.cutDetected && it.sceneId == 4 && !it.stable })
    println("CameraSceneDetector tests: PASS (rapid double cut, settling, ordinary motion, subsequent cut)")
}
