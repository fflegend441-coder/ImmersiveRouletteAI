package com.example.liveroulette

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frame-to-frame visual motion tracker for a roulette-like circular region.
 * It reports a candidate only when a bright feature is also temporally changing
 * and its angular movement is plausible. The rim search supports an axis-aligned
 * ellipse for moderate oblique views. It remains an experimental visual aid, not
 * a calibrated ball detector or an outcome predictor.
 */
internal class LiveWheelBallTracker {
    data class Observation(
        val wheelVisible: Boolean,
        val candidateFound: Boolean,
        val candidateAngleDegrees: Float?,
        val angularDeltaDegrees: Float?,
        val angularSpeedDegreesPerSecond: Float?,
        val confidence: Float,
        val view: String,
        val trackingState: String
    )

    private val width = 320
    private val height = 480
    private var previousGray: ByteArray? = null
    private var previousAngle: Float? = null
    private var previousCenterX = -1f
    private var previousCenterY = -1f
    private var previousFrameAt = 0L
    private var lastTrackedAt = 0L

    fun reset() {
        previousGray = null
        previousAngle = null
        previousCenterX = -1f
        previousCenterY = -1f
        previousFrameAt = 0L
        lastTrackedAt = 0L
    }

    fun analyze(bitmap: Bitmap): Observation {
        if (bitmap.width < 160 || bitmap.height < 240) {
            reset()
            return empty("unknown", "frame too small")
        }
        // Fit the source into the analysis surface without stretching its aspect ratio.
        // The previous implementation distorted every source to 2:3, shifting circular geometry.
        val small = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(small)
            canvas.drawColor(Color.BLACK)
            val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val drawW = bitmap.width * scale
            val drawH = bitmap.height * scale
            val dst = RectF((width - drawW) / 2f, (height - drawH) / 2f,
                (width + drawW) / 2f, (height + drawH) / 2f)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(bitmap, null, dst, paint)
            val gray = ByteArray(width * height)
            for (y in 0 until height) for (x in 0 until width) {
                gray[y * width + x] = gray(small.getPixel(x, y)).toByte()
            }
            // Keep the previous frame for temporal-difference candidate scoring.
            // Without this local snapshot, the tracker referenced an undefined name
            // and the Kotlin source could not compile.
            val oldGray = previousGray

            // Search the FULL analysis frame for a wheel ellipse. Earlier versions
            // searched only the upper half, so a camera cut that moved the wheel
            // lower/sideways could never reacquire it. A coarse global pass is
            // followed by a local refinement around the strongest candidate.
            var bestRing = 0.0
            var cxBest = width / 2
            var cyBest = height / 2
            var radiusXBest = 86
            var radiusYBest = 70

            fun ringScore(cx: Int, cy: Int, rx: Int, ry: Int): Double {
                if (rx < 28 || ry < 24 || cx - rx < 3 || cx + rx >= width - 3 ||
                    cy - ry < 3 || cy + ry >= height - 3) return 0.0
                var edge = 0.0
                for (a in 0 until 32) {
                    val angle = 2.0 * PI * a / 32.0
                    val x = (cx + cos(angle) * rx).toInt()
                    val y = (cy + sin(angle) * ry).toInt()
                    val ix = y * width + x
                    edge += abs((gray[ix].toInt() and 0xff) - (gray[ix - 3].toInt() and 0xff)) +
                        abs((gray[ix].toInt() and 0xff) - (gray[ix + 3].toInt() and 0xff)) +
                        abs((gray[ix].toInt() and 0xff) - (gray[ix - width].toInt() and 0xff)) * 0.35
                }
                return edge / 75.2
            }

            for (rx in 32..116 step 12) for (ratioStep in 0..4) {
                val ry = (rx * (0.58 + ratioStep * 0.105)).toInt()
                if (ry !in 26..116) continue
                for (cy in (ry + 8)..(height - ry - 8) step 16) {
                    for (cx in (rx + 8)..(width - rx - 8) step 16) {
                        val score = ringScore(cx, cy, rx, ry)
                        if (score > bestRing) {
                            bestRing = score; cxBest = cx; cyBest = cy
                            radiusXBest = rx; radiusYBest = ry
                        }
                    }
                }
            }
            // Refine the best coarse candidate to reduce center/radius quantization.
            val coarseCx = cxBest
            val coarseCy = cyBest
            val coarseRx = radiusXBest
            for (rx in (coarseRx - 10).coerceAtLeast(28)..(coarseRx + 10).coerceAtMost(124) step 4) {
                for (ratioStep in 0..4) {
                    val ry = (rx * (0.58 + ratioStep * 0.105)).toInt()
                    if (ry !in 24..120) continue
                    for (cy in (coarseCy - 14).coerceAtLeast(ry + 3)..(coarseCy + 14).coerceAtMost(height - ry - 4) step 4) {
                        for (cx in (coarseCx - 14).coerceAtLeast(rx + 3)..(coarseCx + 14).coerceAtMost(width - rx - 4) step 4) {
                            val score = ringScore(cx, cy, rx, ry)
                            if (score > bestRing) {
                                bestRing = score; cxBest = cx; cyBest = cy
                                radiusXBest = rx; radiusYBest = ry
                            }
                        }
                    }
                }
            }
            val radiusBest = kotlin.math.sqrt(radiusXBest.toDouble() * radiusYBest).toInt()
            val ringConfidence = ((bestRing - 8.0) / 42.0).toFloat().coerceIn(0f, 1f)
            val view = classifyView(bitmap, cxBest, cyBest, radiusBest, ringConfidence)
            if (ringConfidence < 0.18f) {
                previousGray = gray
                previousFrameAt = System.currentTimeMillis()
                resetTrackOnly()
                return Observation(false, false, null, null, null, ringConfidence, view, "wheel not localized")
            }

            val centerX = cxBest / width.toFloat()
            val centerY = cyBest / height.toFloat()
            // A relocated wheel invalidates the old angular coordinate system.
            if (previousCenterX >= 0f &&
                (abs(centerX - previousCenterX) > 0.10f || abs(centerY - previousCenterY) > 0.10f)) {
                previousAngle = null
                lastTrackedAt = 0L
            }
            // Aggregate pixels into angular sectors. Selecting one brightest pixel
            // made reflections/noise jump randomly between frames.
            val sectorCount = 72
            val sectorScores = DoubleArray(sectorCount)
            val sectorSin = DoubleArray(sectorCount)
            val sectorCos = DoubleArray(sectorCount)
            val sectorTemporal = IntArray(sectorCount)
            val sectorCounts = IntArray(sectorCount)
            // Work in normalized ellipse coordinates so angular sectors remain
            // stable when the wheel is vertically compressed by camera perspective.
            val inner = 0.78
            val outer = 1.22
            for (y in max(1, cyBest - radiusYBest - 18)..min(height - 2, cyBest + radiusYBest + 18)) {
                for (x in max(1, cxBest - radiusXBest - 18)..min(width - 2, cxBest + radiusXBest + 18)) {
                    val dx = x - cxBest
                    val dy = y - cyBest
                    val ex = dx.toDouble() / radiusXBest.coerceAtLeast(1)
                    val ey = dy.toDouble() / radiusYBest.coerceAtLeast(1)
                    val radial = hypot(ex, ey)
                    if (radial < inner || radial > outer) continue
                    val idx = y * width + x
                    val lum = gray[idx].toInt() and 0xff
                    if (lum < 178) continue
                    val temporal = if (oldGray != null && oldGray.size == gray.size)
                        abs(lum - (oldGray[idx].toInt() and 0xff)) else 0
                    // Brightness alone is not enough: require temporal change after warm-up.
                    if (oldGray != null && temporal < 18) continue
                    val localContrast = abs(lum - (gray[idx - 1].toInt() and 0xff)) +
                        abs(lum - (gray[idx + 1].toInt() and 0xff)) +
                        abs(lum - (gray[idx - width].toInt() and 0xff)) +
                        abs(lum - (gray[idx + width].toInt() and 0xff))
                    val score = lum * 0.25 + temporal * 1.6 + localContrast * 0.20
                    if (score > 105.0) {
                        val angle = atan2(ey, ex)
                        val sector = (((angle + PI) / (2.0 * PI)) * sectorCount).toInt().coerceIn(0, sectorCount - 1)
                        sectorScores[sector] += score
                        sectorSin[sector] += sin(angle) * score
                        sectorCos[sector] += cos(angle) * score
                        sectorTemporal[sector] += temporal
                        sectorCounts[sector]++
                    }
                }
            }
            val candidates = (0 until sectorCount).filter { sectorCounts[it] >= 3 }
                .map { sector ->
                    Candidate(atan2(sectorSin[sector], sectorCos[sector]).toFloat(),
                        sectorScores[sector], sectorTemporal[sector] / sectorCounts[sector])
                }

            // Choose a coherent angular cluster near the prior track, not an isolated pixel.
            val now = System.currentTimeMillis()
            val oldAngle = previousAngle
            val selected = if (candidates.isEmpty()) null else if (oldAngle == null) {
                candidates.maxByOrNull { it.score }
            } else {
                candidates.maxByOrNull { c ->
                    val delta = angleDelta(c.angle, oldAngle)
                    val continuity = if (abs(delta) <= 65f) 1.0 else 0.08
                    c.score * continuity
                }?.takeIf { abs(angleDelta(it.angle, oldAngle)) <= 65f }
            }
            val delta = if (selected != null && oldAngle != null) angleDelta(selected.angle, oldAngle) else null
            val elapsed = if (previousFrameAt > 0L) ((now - previousFrameAt).coerceAtLeast(1L) / 1000f) else 0f
            val speed = if (delta != null && elapsed > 0f) delta / elapsed else null
            if (selected != null) {
                previousAngle = selected.angle
                lastTrackedAt = now
            } else if (now - lastTrackedAt > 1200L) {
                previousAngle = null
            }

            previousCenterX = centerX
            previousCenterY = centerY
            previousGray = gray
            previousFrameAt = now

            val candidateConfidence = if (selected == null) 0f else
                (0.25f + selected.temporal / 100f + ringConfidence * 0.25f).coerceIn(0f, 0.85f)
            val state = when {
                selected == null && oldGray == null -> "warming up"
                selected == null -> "candidate lost / reacquiring"
                oldAngle == null -> "candidate acquired; direction pending"
                abs(delta ?: 999f) > 80f -> "unstable candidate"
                else -> "candidate tracked; validate visually"
            }
            return Observation(true, selected != null, selected?.angle?.let { Math.toDegrees(it.toDouble()).toFloat() }, delta,
                speed, (ringConfidence * 0.45f + candidateConfidence * 0.55f).coerceIn(0f, 1f), view, state)
        } finally {
            small.recycle()
        }
    }

    private data class Candidate(val angle: Float, val score: Double, val temporal: Int)
    private fun resetTrackOnly() { previousAngle = null; lastTrackedAt = 0L }
    private fun empty(view: String, state: String) = Observation(false, false, null, null, null, 0f, view, state)
    private fun angleDelta(current: Float, previous: Float): Float {
        var d = current - previous
        while (d > PI.toFloat()) d -= (2f * PI.toFloat())
        while (d < -PI.toFloat()) d += (2f * PI.toFloat())
        return Math.toDegrees(d.toDouble()).toFloat()
    }
    private fun classifyView(bitmap: Bitmap, cx: Int, cy: Int, radius: Int, confidence: Float): String {
        val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val normalizedRadius = radius.toFloat() / height
        return when {
            confidence < 0.25f -> "wheel view uncertain"
            ratio > 0.78f -> "wide camera view"
            normalizedRadius > 0.19f -> "wheel close-up candidate"
            cy < height * 0.30f -> "upper wheel view candidate"
            else -> "portrait table view candidate"
        }
    }
    // Grayscale values are stored as signed Kotlin Bytes; always convert to 0..255.
    private fun gray(color: Int): Int = (Color.red(color) * 30 + Color.green(color) * 59 + Color.blue(color) * 11) / 100
}
