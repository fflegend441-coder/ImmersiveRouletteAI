package com.example.liveroulette

import kotlin.math.abs

/**
 * Lightweight camera-cut/stability detector. Input is a row-major normalized
 * luminance signature (0..255). It detects abrupt frame-wide scene changes and
 * waits for a few consistent frames before declaring the view stable.
 * It intentionally does not identify people or claim a wheel ROI by itself.
 */
internal class CameraSceneDetector(
    private val cutMeanThreshold: Double = 29.0,
    private val cutChangedRatioThreshold: Double = 0.48,
    private val stableMeanThreshold: Double = 9.0,
    private val stableFramesRequired: Int = 3
) {
    data class Result(
        val cutDetected: Boolean,
        val stable: Boolean,
        val sceneId: Int,
        val meanDifference: Double,
        val changedRatio: Double,
        val motionLabel: String
    )

    private var previous: IntArray? = null
    private var sceneId = 1
    private var stableFrames = 0
    // Once a new camera view has settled, keep it ready while the wheel/ball moves.
    // Ordinary motion must not repeatedly disable tracking; only a detected cut resets it.
    private var sceneReady = false

    fun reset() {
        previous = null
        stableFrames = 0
        sceneReady = false
        sceneId = 1
    }

    fun update(luminance: IntArray): Result {
        require(luminance.isNotEmpty()) { "luminance signature must not be empty" }
        val old = previous
        if (old == null || old.size != luminance.size) {
            previous = luminance.copyOf()
            stableFrames = 1
            sceneReady = stableFrames >= stableFramesRequired
            return Result(false, sceneReady, sceneId, 0.0, 0.0, "warming up")
        }

        var total = 0L
        var changed = 0
        for (i in luminance.indices) {
            val delta = abs(luminance[i].coerceIn(0, 255) - old[i].coerceIn(0, 255))
            total += delta
            if (delta >= 44) changed++
        }
        val mean = total.toDouble() / luminance.size
        val ratio = changed.toDouble() / luminance.size
        // Do not apply a time-based cooldown here: live roulette feeds can cut
        // from wheel -> presenter -> wheel in well under 650 ms. The signature
        // is compared with the immediately previous frame, so a real second cut
        // is independently detected without suppressing rapid transitions.
        val cut = mean >= cutMeanThreshold && ratio >= cutChangedRatioThreshold

        if (cut) {
            sceneId++
            stableFrames = 0
            sceneReady = false
        } else if (mean <= stableMeanThreshold) {
            stableFrames++
            if (stableFrames >= stableFramesRequired) sceneReady = true
        } else {
            stableFrames = 0
            // Keep an already-ready scene ready during ordinary in-scene motion.
        }

        previous = luminance.copyOf()
        val label = when {
            cut -> "abrupt scene transition"
            mean > stableMeanThreshold && !sceneReady -> "camera motion / angle changing"
            !sceneReady -> "new view stabilizing"
            mean > stableMeanThreshold -> "in-scene motion"
            else -> "view stable"
        }
        return Result(cut, sceneReady, sceneId, mean, ratio, label)
    }
}
