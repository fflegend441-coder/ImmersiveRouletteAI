Immersive Roulette AI - Version 6.6 source

Version 6.6 source corrections:
1. OCR is restricted to the top live History strip region shown in the supplied portrait screenshot (normalized y=9.5%-14.2%), then enlarged 2x before ML Kit recognition. Betting-grid numbers and unrelated screen text are no longer considered.
2. A valid 10-15 number horizontal History row is required. If it cannot be read, no result is added.
3. Stable OCR snapshots tolerate up to two character/number recognition differences; history alignment tolerates up to three edit operations while retaining a strong sequence-overlap threshold.
4. If a valid but unaligned History row persists for five stable scans, the app safely re-syncs its baseline without counting the row as a new spin. This prevents permanent "History মিলছে না" lock-up.
5. The exact visible History baseline is persisted separately from accumulated history. This prevents a false duplicate spin after app restart when the live strip contains 14 values (or another supported 10-15 count).
6. STAR OFF starts with the VirtualDisplay surface detached. STAR ON attaches the ImageReader surface; STAR OFF detaches it again. OCR runs only while STAR is on.
7. Existing European wheel sector heuristic is retained. Roulette outcomes are independent; the displayed number is a statistical heuristic, not a guaranteed prediction.

Important:
- The crop is tuned to the supplied portrait Immersive Roulette screenshot. If the casino app changes its top layout or is used in landscape/zoom mode, the crop coordinates may need adjustment.
- This environment does not have Android SDK/Gradle installed, so an APK build could not be run here. Please build with the included GitHub Actions workflow or Android Studio, then test on the actual phone.

V6.4: সরবরাহ করা 675x1500 স্ক্রিনশট অনুযায়ী History Row crop y=10.5%-13.5% এ সংকুচিত করা হয়েছে।


V6.5 পরিবর্তন:
- History row-এর rolling shift শনাক্তকরণকে OCR noise check-এর আগে চালানো হয়েছে।
- এক রাউন্ডে বাম পাশে নতুন ফল এলে সেটি আর একই History ভেবে বাদ পড়বে না।
- History crop-এর vertical margin সামান্য বাড়ানো হয়েছে।
- Floating panel-এর রং গাঢ় নীল-বেগুনি ও সায়ান বর্ডার করা হয়েছে।

V6.6 অতিরিক্ত যাচাই/সংশোধন:
- OCR line fallback-এ invalid token বাদ পড়লে পরের token-এর horizontal position ভুল হয়ে যেত; value ও text-span একসাথে রেখে সেটি ঠিক করা হয়েছে।
- STAR OFF করলে আগের prediction-ও লুকানো হবে; pause অবস্থায় পুরোনো নম্বর দেখাবে না।
- APK compile এই পরিবেশে চালানো যায়নি; GitHub Actions build সফল না হওয়া পর্যন্ত compile-tested বলা যাবে না।


V6.7 সংশোধন:
- STAR OFF/ON করলে cached prediction reset হয়, ফলে একই History আবার শনাক্ত হলে Prediction ফিরে আসে।
- সংরক্ষিত History এবং দৃশ্যমান History Row-এর মিল যাচাই করা হয়; অমিল হলে বর্তমান Row থেকে নিরাপদে re-sync হয়।
- নির্ভরযোগ্য baseline না থাকলে পুরোনো saved history-এর সঙ্গে নতুন row মিশিয়ে ফেলা হয় না।


V6.8 আপডেট:
- Usage Access দিয়ে foreground app শনাক্ত করার ব্যবস্থা যোগ করা হয়েছে।
- ইনস্টল করা launcher app-এর নাম থেকে 1xBet package খুঁজে নেওয়া হয়; নির্দিষ্ট package ID hard-code করা হয়নি।
- STAR ON থাকলেও 1xBet সামনে না থাকলে MediaProjection capture surface detach থাকে।
- 1xBet সামনে এলে capture surface attach হয়; অন্য অ্যাপে গেলে detach হয়।
- Main screen-এ Usage Access Settings খোলার বোতাম যোগ করা হয়েছে।
- Android 11+ package visibility-এর জন্য launcher query যোগ করা হয়েছে।


V6.9 European Strategy Panel:
- Floating panel-এর ROULETTE • INFO শিরোনামে চাপলে Strategy details expand/collapse হবে।
- European single-zero wheel order দিয়ে সর্বশেষ ফলের দুই পাশের দুইটি করে wheel neighbour দেখায়।
- Standard Voisins du Zéro (17), Tiers du Cylindre (12), Orphelins (8) group-এর history frequency ও percentage দেখায়।
- সর্বশেষ 100টি সংরক্ষিত ফল থেকে Hot numbers, low-frequency numbers এবং top 3 final digits দেখায়।
- এগুলো অতীতের frequency/sector summary; স্বাধীন roulette spin-এর পরের ফল নিশ্চিতভাবে বলে না।
- Version 6.9 / versionCode 15। Android build ও বাস্তব ফোনে OCR/panel পরীক্ষা এখনও করতে হবে।

V6.10: 1xBet screenshot-er history row-er exact position onujayi OCR crop tight kora hoyeche; row crop 3x upscale; OCR miss hole abar retry status dekhabe. Android build/device validation baki.
