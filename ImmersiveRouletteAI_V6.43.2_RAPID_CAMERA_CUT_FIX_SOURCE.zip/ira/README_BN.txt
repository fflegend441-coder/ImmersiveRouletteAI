ImmersiveRouletteAI V6.43.2 — Camera Scene Stability Fix

Changes in V6.43.2:
- CameraSceneDetector now latches a scene as ready after the required stable frames.
- Ordinary motion inside an already-settled scene no longer drops the ready state. This matters because the roulette wheel and ball continue moving while the camera remains on the same shot.
- A detected camera cut clears the ready state and increments the scene ID.
- CaptureService resets wheel tracking while the new scene is settling, then resumes analysis only after the scene is ready.
- Updated Android version to 6.43.2 (versionCode 52) and the GitHub Actions artifact label.
- Kept BuildConfig generation enabled for the floating-panel version label.

Validation performed for this archive:
- ZIP integrity check.
- AndroidManifest XML parse.
- GitHub Actions YAML parse.
- Version and panel-label source consistency checks.
- CameraSceneDetector compiled with Kotlin/JVM and exercised by a local deterministic test harness.

Not validated here:
- Full Android APK build (Android SDK/Gradle/Android plugin are not installed in this environment).
- Runtime capture on a physical Android device.
- Real 1xBet live-game OCR, camera-angle reacquisition, or ball tracking.

Important limitations:
- The camera detector uses a coarse luminance signature; it is not semantic presenter/wheel recognition.
- Wheel localization remains an experimental ellipse candidate search, not calibrated perspective correction.
- Bright moving pixels are only ball candidates; the tracker is not a verified physical ball tracker.
- Roulette outcomes are random; this app cannot guarantee or reliably predict a winning number.

Build:
- Open the project root in Android Studio with Android SDK 35 and Java 17 configured, or run `gradle assembleDebug` in a configured Android build environment.

V6.43.2 recheck fix:
- Removed the 650 ms camera-cut cooldown. Two genuine scene changes inside 650 ms are now detected independently.
- Cleaned up motion-state label ordering.
- Added deterministic Kotlin tests for rapid cuts, scene settling, and ordinary motion.
- Android APK build and real 1xBet runtime validation still require Android SDK/device testing.
