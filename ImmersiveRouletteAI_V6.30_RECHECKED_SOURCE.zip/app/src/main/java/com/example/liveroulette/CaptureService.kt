package com.example.liveroulette

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.pm.PackageManager
import android.os.Process
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import kotlin.math.abs

class CaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "roulette_ocr_capture"
        private const val NOTIFICATION_ID = 7102
        private const val ACTION_STOP = MainActivity.ACTION_STOP
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var predictionView: TextView? = null
    private val alternatePredictionViews = mutableListOf<TextView>()
    private var statusView: TextView? = null
    private var starButton: TextView? = null
    private var strategyView: TextView? = null
    private var strategyExpanded = false
    private var panelParams: WindowManager.LayoutParams? = null

    @Volatile private var scanActive = false
    @Volatile private var processing = false
    @Volatile private var captureAttached = false
    private var targetAppPackage: String? = null
    private var lastUsageQueryAt = 0L
    private var cachedForegroundPackage: String? = null
    // Do not let the 1-second foreground watcher overwrite OCR diagnostics.
    private var lastWatcherStatus: String? = null
    private var foregroundWatcher: Runnable? = null
    private var lastOcrAt = 0L
    private var pendingNumbers: List<Int> = emptyList()
    private var pendingRepeats = 0
    private var pendingExactRepeats = 0
    private var mismatchSnapshot: List<Int> = emptyList()
    private var mismatchRepeats = 0
    private var mismatchExactRepeats = 0
    private var mismatchFirstNumber: Int? = null
    private var mismatchFirstRepeats = 0
    // The game strip is newest-first (left to right) on the supplied game screen.
    private var previousNumbers: List<Int> = emptyList()
    private var visibleHistory: List<Int> = emptyList()
    private var lastPrediction: Int? = null
    private var lastPredictionAlternates: List<Int> = emptyList()
    private val recentHistory = ArrayDeque<Int>()
    private val historyPrefs by lazy { getSharedPreferences("roulette_history", Context.MODE_PRIVATE) }
    private val numberRegex = Regex("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)")

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadSavedHistory()
        // A service restart starts a fresh OCR session. Never display a persisted
        // pick as though it belongs to the current round; rebuild it from confirmed
        // live history after the screen strip is read.
        lastPrediction = null
        lastPredictionAlternates = emptyList()
        savePrediction()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        if (projection == null) {
            val resultCode = intent?.getIntExtra(MainActivity.EXTRA_RESULT_CODE, 0) ?: 0
            val resultData = intent?.getParcelableExtra<Intent>(MainActivity.EXTRA_RESULT_DATA)
            if (resultCode == 0 || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            startProjection(resultCode, resultData)
            showPanel()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)
        scanActive = false
        captureAttached = false

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        workerThread = HandlerThread("RouletteOCRWorker").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)

        // Android 14+ requires the callback to be registered before the first
        // VirtualDisplay is created for this MediaProjection session.
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                scanActive = false
                stopSelf()
            }
        }, workerHandler)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                try {
                    if (scanActive && captureAttached && !processing && System.currentTimeMillis() - lastOcrAt >= 650L) {
                        lastOcrAt = System.currentTimeMillis()
                        processImage(image)
                    }
                } finally {
                    image.close()
                }
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "RouletteOCRDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            // Do not capture the screen until the user explicitly enables STAR.
            null,
            null,
            workerHandler
        )

        updateStatus("STAR OFF • চালু করতে STAR চাপুন")
    }

    /**
     * Find the installed launcher app whose visible name contains "1xBet".
     * This avoids hard-coding a package name because official app packages can
     * differ by distribution/region.
     */
    @Suppress("DEPRECATION")
    private fun findOneXBetPackage(): String? {
        targetAppPackage?.let { return it }
        return try {
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val activities = packageManager.queryIntentActivities(launcherIntent, 0)
            val match = activities.firstOrNull { info ->
                val activityLabel = runCatching {
                    info.loadLabel(packageManager).toString()
                }.getOrDefault("")
                val appLabel = runCatching {
                    info.activityInfo.applicationInfo.loadLabel(packageManager).toString()
                }.getOrDefault("")
                activityLabel.contains("1xbet", ignoreCase = true) ||
                    appLabel.contains("1xbet", ignoreCase = true)
            }
            match?.activityInfo?.packageName?.also { targetAppPackage = it }
        } catch (_: Exception) {
            null
        }
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    /** Update the cached foreground package from UsageEvents. */
    private fun refreshForegroundPackage(): String? {
        val now = System.currentTimeMillis()
        val from = if (lastUsageQueryAt == 0L) now - 24L * 60L * 60L * 1000L else (lastUsageQueryAt - 1500L).coerceAtLeast(0L)
        return try {
            val usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val events = usage.queryEvents(from, now)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val foregroundEvent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                } else {
                    @Suppress("DEPRECATION")
                    event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                }
                if (foregroundEvent && !event.packageName.isNullOrBlank()) {
                    cachedForegroundPackage = event.packageName
                }
            }
            lastUsageQueryAt = now
            cachedForegroundPackage
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Capture is attached only while STAR is ON and the foreground app is the
     * installed 1xBet app. Usage Access is a one-time Android special permission.
     */
    private fun startForegroundWatcher() {
        val handler = workerHandler ?: return
        foregroundWatcher?.let { handler.removeCallbacks(it) }
        val watcher = object : Runnable {
            override fun run() {
                if (!scanActive) {
                    if (captureAttached) virtualDisplay?.setSurface(null)
                    captureAttached = false
                    return
                }

                if (!hasUsageAccess()) {
                    if (captureAttached) virtualDisplay?.setSurface(null)
                    captureAttached = false
                    updateWatcherStatus("1xBet শনাক্ত করতে Usage Access দিন")
                } else {
                    val target = findOneXBetPackage()
                    val foreground = refreshForegroundPackage()
                    if (target == null) {
                        if (captureAttached) virtualDisplay?.setSurface(null)
                        captureAttached = false
                        updateWatcherStatus("ইনস্টল করা 1xBet App পাওয়া যায়নি")
                    } else if (foreground == target) {
                        if (!captureAttached) {
                            virtualDisplay?.setSurface(imageReader?.surface)
                            captureAttached = true
                        }
                        updateWatcherStatus("1xBet সামনে আছে • History Scan চালু")
                    } else {
                        if (captureAttached) virtualDisplay?.setSurface(null)
                        captureAttached = false
                        updateWatcherStatus("1xBet Roulette খুলুন • Scan অপেক্ষায়")
                    }
                }
                handler.postDelayed(this, 1000L)
            }
        }
        foregroundWatcher = watcher
        handler.post(watcher)
    }

    private fun updateWatcherStatus(message: String) {
        if (lastWatcherStatus != message) {
            lastWatcherStatus = message
            updateStatus(message)
        }
    }

    private fun stopForegroundWatcher() {
        foregroundWatcher?.let { workerHandler?.removeCallbacks(it) }
        foregroundWatcher = null
        if (captureAttached) virtualDisplay?.setSurface(null)
        captureAttached = false
    }

    private fun processImage(image: Image) {
        if (!scanActive || !captureAttached || processing) return

        // The live results strip is at the top of the supplied portrait game
        // layout. OCR only this narrow region instead of mixing in the betting
        // grid, balance, timer, and other unrelated screen numbers.
        val fullBitmap = imageToBitmap(image) ?: return
        val historyBitmap = cropHistoryStrip(fullBitmap)
        if (historyBitmap == null) {
            fullBitmap.recycle()
            updateStatus("History strip crop করা যায়নি")
            return
        }

        processing = true
        recognizer.process(InputImage.fromBitmap(historyBitmap, 0))
            .addOnSuccessListener { result ->
                if (!scanActive || !captureAttached) return@addOnSuccessListener
                val numbers = extractHistoryNumbers(result)
                if (numbers.size in 10..15) {
                    registerHistorySnapshot(numbers)
                } else {
                    // A single blurred frame must not erase a nearly stable row.
                    // Keep the last candidate; the next good frame can confirm it.
                    val raw = result.text.replace('\n', ' ').take(42)
                    updateStatus("History OCR: ${numbers.size} নম্বর • ${result.textBlocks.size} blocks • $raw")
                }
            }
            .addOnFailureListener {
                // Do not reset the pending stable-row counter for one transient
                // ML Kit failure; otherwise three clean frames may never arrive.
                updateStatus("OCR frame miss • আগের History ধরে আবার চেষ্টা করছি")
            }
            .addOnCompleteListener {
                processing = false
                if (!historyBitmap.isRecycled) historyBitmap.recycle()
                if (!fullBitmap.isRecycled) fullBitmap.recycle()
            }
    }

    /**
     * Crop only the top results strip from the supplied 674x1536 portrait
     * 1xBet screenshot. The visible history cells occupy y=162..196
     * (about 10.5%-12.8% of screen height). Keep a small safety margin
     * to avoid clock/video text entering the OCR region.
     */
    private fun cropHistoryStrip(source: Bitmap): Bitmap? {
        return try {
            if (source.width < 200 || source.height < 400) return null
            // Tight crop around the actual horizontal number row. The previous
            // 9.5%-14.5% crop included too much of the video/header and made
            // ML Kit alternate between a valid row and unrelated text.
            val top = (source.height * 0.102f).toInt().coerceIn(0, source.height - 2)
            val bottom = (source.height * 0.131f).toInt().coerceIn(top + 1, source.height)
            val strip = Bitmap.createBitmap(source, 0, top, source.width, bottom - top)
            val scaled = Bitmap.createScaledBitmap(
                strip,
                (strip.width * 3).coerceAtMost(2400),
                (strip.height * 3).coerceAtMost(600),
                true
            )
            if (scaled !== strip) strip.recycle()
            scaled
        } catch (_: Exception) {
            null
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Reconstruct horizontal OCR rows from word boxes. The live game normally
     * exposes 13 recent results in one strip; betting-grid rows have only three
     * values, while the expanded 500-result statistics view is a different layout.
     * Ambiguous rows are rejected instead of guessing from an arbitrary screen row.
     */
    private fun extractHistoryNumbers(result: Text): List<Int> {
        data class Token(val value: Int, val left: Int, val centerY: Int, val top: Int, val bottom: Int)
        data class Candidate(val values: List<Int>, val top: Int, val width: Int)

        val elementTokens = mutableListOf<Token>()
        val fallbackTokens = mutableListOf<Token>()
        val singleCellPattern = Regex("(?:[0-9]|[12][0-9]|3[0-6])")
        // Collect element boxes across ALL OCR blocks. ML Kit often splits the
        // horizontal history strip into several blocks (e.g. 4 + 5 + 5 cells).
        // Requiring 10+ cells inside one line/block silently rejected that valid row.
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val lineBox = line.boundingBox ?: continue
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    val raw = element.text.trim().uppercase()
                    val normalized = if (raw.length <= 2) raw
                        .replace('O', '0').replace('Q', '0')
                        .replace('I', '1').replace('L', '1')
                        .replace('|', '1').replace('S', '5').replace('B', '8')
                    else raw
                    if (!singleCellPattern.matches(normalized)) continue
                    val value = normalized.toIntOrNull() ?: continue
                    if (value in 0..36) {
                        elementTokens += Token(value, box.left, box.centerY(), box.top, box.bottom)
                    }
                }
                // Fallback spans are also collected across blocks/lines, then
                // grouped by their OCR y-coordinate below.
                val matches = numberRegex.findAll(line.text).mapNotNull { match ->
                    val value = match.value.toIntOrNull()
                    if (value != null && value in 0..36) match to value else null
                }.toList()
                matches.forEach { (match, value) ->
                    val left = lineBox.left +
                        (lineBox.width() * match.range.first / line.text.length.coerceAtLeast(1))
                    fallbackTokens += Token(value, left, lineBox.centerY(), lineBox.top, lineBox.bottom)
                }
            }
        }
        // Group each OCR source independently by vertical position. Do not reject
        // all element boxes just because one stray token makes the total >15; that
        // was causing valid history rows to be discarded when OCR saw a nearby digit.
        fun candidatesFrom(source: List<Token>): List<Candidate> {
            if (source.size < 10) return emptyList()
            val typicalHeight = source.map { (it.bottom - it.top).coerceAtLeast(1) }.sorted()
                .let { it[it.size / 2] }
            val rowTolerance = maxOf(7, (typicalHeight * 0.85f).toInt())
            val rows = mutableListOf<MutableList<Token>>()
            for (token in source.sortedBy { it.centerY }) {
                val row = rows.minByOrNull { group ->
                    abs(group.map { it.centerY }.average() - token.centerY)
                }
                if (row != null && abs(row.map { it.centerY }.average() - token.centerY) <= rowTolerance) {
                    row += token
                } else {
                    rows += mutableListOf(token)
                }
            }
            return rows.mapNotNull { row ->
                val ordered = row.sortedBy { it.left }
                // Remove adjacent duplicate OCR tokens at almost the same x position.
                val deduped = ordered.fold(mutableListOf<Token>()) { acc, token ->
                    val prior = acc.lastOrNull()
                    if (prior == null || token.left - prior.left > maxOf(5, typicalHeight / 3)) acc += token
                    acc
                }
                val values = deduped.map { it.value }
                if (values.size !in 10..15) null
                else Candidate(values, deduped.minOf { it.top }, deduped.last().left - deduped.first().left)
            }
        }

        val candidates = (candidatesFrom(elementTokens) + candidatesFrom(fallbackTokens))
            .distinctBy { it.values }
            .sortedWith(
                compareBy<Candidate> { abs(it.values.size - 13) }
                    .thenByDescending { it.width }
                    .thenBy { it.top }
            )
        val best = candidates.firstOrNull() ?: return emptyList()
        val second = candidates.getOrNull(1)
        if (second != null && second.values != best.values &&
            abs(second.values.size - 13) == abs(best.values.size - 13) &&
            second.width >= (best.width * 0.85f).toInt()) return emptyList()
        return best.values
    }

    private fun loadSavedHistory() {
        val saved = historyPrefs.getString("numbers", "").orEmpty()
            .split(',').mapNotNull { it.toIntOrNull() }.filter { it in 0..36 }.take(100)
        recentHistory.clear()
        saved.forEach { recentHistory.addLast(it) }

        // Persist the exact visible strip separately. Taking an arbitrary 13
        // values from the longer history can create a false "new spin" after
        // restart when the live strip contains 14 or another supported count.
        val baseline = historyPrefs.getString("visible_baseline", "").orEmpty()
            .split(',').mapNotNull { it.toIntOrNull() }.filter { it in 0..36 }
        if (baseline.size in 10..15) {
            previousNumbers = baseline
            visibleHistory = baseline
        }
    }

    private fun saveHistory() {
        historyPrefs.edit()
            .putString("numbers", recentHistory.joinToString(","))
            .putString("visible_baseline", previousNumbers.joinToString(","))
            .apply()
    }

    private fun loadSavedPrediction() {
        val savedMain = historyPrefs.getInt("active_prediction", -1)
        lastPrediction = savedMain.takeIf { it in 0..36 }
        lastPredictionAlternates = historyPrefs.getString("active_prediction_alternates", "")
            .orEmpty()
            .split(',')
            .mapNotNull { it.toIntOrNull() }
            .filter { it in 0..36 && it != lastPrediction }
            .distinct()
            .take(3)
    }

    private fun savePrediction() {
        historyPrefs.edit()
            .putInt("active_prediction", lastPrediction ?: -1)
            .putString("active_prediction_alternates", lastPredictionAlternates.joinToString(","))
            .apply()
    }

    private fun registerHistorySnapshot(numbers: List<Int>) {
        // Require either two identical OCR rows or three near-identical rows.
        // This avoids promoting a one-frame OCR substitution to a new spin.
        val exactPending = numbers == pendingNumbers
        val nearPending = pendingNumbers.isNotEmpty() &&
            numbers.size == pendingNumbers.size && sequenceEditDistance(numbers, pendingNumbers) <= 1
        if (exactPending) {
            pendingRepeats++
            pendingExactRepeats++
        } else if (nearPending) {
            pendingRepeats++
            pendingExactRepeats = 1
            pendingNumbers = numbers
        } else {
            pendingNumbers = numbers
            pendingRepeats = 1
            pendingExactRepeats = 1
        }
        if (pendingExactRepeats < 2 && pendingRepeats < 3) {
            updateStatus("History OCR নিশ্চিত হচ্ছে • exact $pendingExactRepeats/2 • stable $pendingRepeats/3")
            return
        }

        if (previousNumbers.isEmpty()) {
            previousNumbers = numbers
            visibleHistory = numbers
            recentHistory.clear()
            numbers.forEach { recentHistory.addLast(it) }
            saveHistory()
            updatePredictionFromHistory("History loaded • ${numbers.size} results", listOf(numbers.first()))
            return
        }

        // Verify that the saved rolling history is still aligned with the last
        // trusted visible strip. A re-sync/scroll/rebuild is NOT evidence of a spin:
        // update the baseline only and wait for a verified rolling overlap.
        val savedPrefix = recentHistory.toList().take(previousNumbers.size)
        if (recentHistory.isEmpty() || savedPrefix != previousNumbers) {
            previousNumbers = numbers
            visibleHistory = numbers
            recentHistory.clear()
            numbers.forEach { recentHistory.addLast(it) }
            saveHistory()
            updateStrategyPanel()
            // The visible row is now our trusted baseline. Clear the stale pick and
            // calculate a fresh descriptive ranking from this confirmed history;
            // do not pretend the re-sync itself was a new spin.
            lastPrediction = null
            lastPredictionAlternates = emptyList()
            savePrediction()
            updatePredictionFromHistory("History re-synced • নতুন baseline")
            return
        }

        // A genuine spin shifts the old strip right: current[1..] should match
        // old[0..]. Detect that rolling overlap before treating changed cells as OCR noise.
        val newResults = findNewResults(previousNumbers, numbers)
        if (newResults.isNotEmpty()) {
            visibleHistory = numbers
            newResults.asReversed().forEach { recentHistory.addFirst(it) }
            while (recentHistory.size > 100) recentHistory.removeLast()
            previousNumbers = numbers
            clearMismatchState()
            saveHistory()
            updatePredictionFromHistory("নতুন ফল • ${recentHistory.size} results", newResults)
            return
        }

        if (numbers == previousNumbers) {
            visibleHistory = numbers
            clearMismatchState()
            if (lastPrediction == null && recentHistory.size >= 12) {
                updatePredictionFromHistory("History restored • ${recentHistory.size} results")
            }
            return
        }

        // No rolling overlap: keep checking the entire row. Even a one-cell
        // change is not discarded forever; it can be accepted after three exact
        // full-row reads, while a transient OCR error cannot unlock the round.
        val exactMismatch = numbers == mismatchSnapshot
        val nearMismatch = mismatchSnapshot.isNotEmpty() &&
            numbers.size == mismatchSnapshot.size && sequenceEditDistance(numbers, mismatchSnapshot) <= 1
        if (exactMismatch) {
            mismatchExactRepeats++
            mismatchRepeats++
        } else if (nearMismatch) {
            mismatchRepeats++
            mismatchExactRepeats = 1
            mismatchSnapshot = numbers
        } else {
            mismatchSnapshot = numbers
            mismatchRepeats = 1
            mismatchExactRepeats = 1
        }

        if (mismatchExactRepeats >= 3 || mismatchRepeats >= 5) {
            // A replaced/rebuilt strip has no trustworthy alignment with the old
            // row. Rebase the history to the confirmed visible row; do not append
            // just its first cell to stale history.
            previousNumbers = numbers
            visibleHistory = numbers
            recentHistory.clear()
            numbers.forEach { recentHistory.addLast(it) }
            clearMismatchState()
            saveHistory()
            // Rebuilt rows may be caused by scrolling, a game-layout change, or
            // OCR drift. Do not append a guessed spin. Re-rank the confirmed visible
            // history so an obsolete prediction is not left frozen on the panel.
            lastPrediction = null
            lastPredictionAlternates = emptyList()
            savePrediction()
            updatePredictionFromHistory("History rebuilt • visible baseline")
            return
        }

        updateStatus("History alignment যাচাই • exact $mismatchExactRepeats/3 • stable $mismatchRepeats/5")
    }

    private fun clearMismatchState() {
        mismatchSnapshot = emptyList()
        mismatchRepeats = 0
        mismatchExactRepeats = 0
        mismatchFirstNumber = null
        mismatchFirstRepeats = 0
    }

    /**
     * New results enter at the LEFT. Compare old from index zero with current starting at the shift
     * using edit distance, so one missed/duplicated OCR token does not break
     * the entire history alignment. Ambiguous or weak matches are rejected.
     */
    private fun findNewResults(old: List<Int>, current: List<Int>): List<Int> {
        if (old.size < 9 || current.size < 9) return emptyList()

        data class Match(val shift: Int, val edits: Int, val overlap: Int)
        val matches = mutableListOf<Match>()
        val maxShift = minOf(6, current.size - 9)

        for (shift in 1..maxShift) {
            val overlap = minOf(old.size, current.size - shift)
            if (overlap < 9) continue
            val oldPart = old.take(overlap)
            val currentPart = current.drop(shift).take(overlap)
            val edits = sequenceEditDistance(oldPart, currentPart)
            val allowedEdits = maxOf(1, overlap / 12)
            if (edits <= allowedEdits) matches += Match(shift, edits, overlap)
        }

        if (matches.isEmpty()) return emptyList()
        val ranked = matches.sortedWith(
            compareBy<Match> { it.edits }
                .thenByDescending { it.overlap }
                .thenBy { it.shift }
        )
        val best = ranked.first()
        // If two alignments are equally plausible, wait for another stable OCR row
        // instead of inventing a spin count.
        val second = ranked.getOrNull(1)
        if (second != null && second.edits == best.edits && second.overlap == best.overlap) {
            return emptyList()
        }
        return current.take(best.shift)
    }

    private fun sequenceEditDistance(a: List<Int>, b: List<Int>): Int {
        var previous = IntArray(b.size + 1) { it }
        for (i in 1..a.size) {
            val current = IntArray(b.size + 1)
            current[0] = i
            for (j in 1..b.size) {
                val substitution = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val deletion = previous[j] + 1
                val insertion = current[j - 1] + 1
                current[j] = minOf(substitution, deletion, insertion)
            }
            previous = current
        }
        return previous[b.size]
    }

    private fun updatePredictionFromHistory(status: String, newResults: List<Int> = emptyList()) {
        updateStrategyPanel()
        if (recentHistory.size < 12) {
            // Never leave an old round's pick displayed as if it were current.
            lastPrediction = null
            lastPredictionAlternates = emptyList()
            savePrediction()
            updatePrediction(null, emptyList())
            updateStatus("নতুন Prediction-এর জন্য আরও History দরকার • ${recentHistory.size}/12")
            return
        }

        // A prediction is recalculated only for a newly confirmed spin.
        // Never exclude the previous pick: the same number may legitimately rank
        // first again from the current history, and forcing a different pick would
        // inject an artificial bias into the analysis.
        val shouldRecalculate = lastPrediction == null || newResults.isNotEmpty()
        if (!shouldRecalculate) {
            updatePrediction(lastPrediction, lastPredictionAlternates)
            updateStatus("$status • একই Round • Prediction স্থির")
            return
        }

        val rankedPicks = rankHistoryGuesses()
        lastPrediction = rankedPicks.firstOrNull()
        lastPredictionAlternates = rankedPicks.drop(1).take(3)
        savePrediction()
        updatePrediction(lastPrediction, lastPredictionAlternates)
        updateStatus(
            when {
                lastPrediction == null -> "$status • Prediction তৈরি হয়নি"
                newResults.isNotEmpty() -> "$status • নতুন Round • Prediction পুনরায় হিসাব হয়েছে"
                else -> "$status • Prediction তৈরি"
            }
        )
    }

    /**
     * Rank numbers outside the currently visible history by their proximity to
     * recent results on the European wheel. This is only a sector heuristic:
     * independent roulette spins do not become predictable from past results.
     */
    private fun rankHistoryGuesses(excludedNumbers: Set<Int> = emptySet()): List<Int> {
        // European single-zero wheel order. This ranks descriptive patterns only;
        // every spin remains independent and the score is not a win probability.
        val wheel = listOf(
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13,
            36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14,
            31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
        )
        val history = recentHistory.toList().take(80) // newest first
        val scores = DoubleArray(37)
        val frequency = IntArray(37)
        val lastSeen = IntArray(37) { history.size + 1 }

        history.forEachIndexed { index, result ->
            if (result !in 0..36) return@forEachIndexed
            frequency[result]++
            if (lastSeen[result] > history.size) lastSeen[result] = index
            val weight = kotlin.math.exp(-index.toDouble() / 16.0)
            val wheelIndex = wheel.indexOf(result)

            // Neighbour sector: nearer pockets get stronger recency-weighted scores.
            for (offset in -5..5) {
                if (offset == 0) continue
                val distance = kotlin.math.abs(offset)
                val candidate = wheel[(wheelIndex + offset + wheel.size) % wheel.size]
                scores[candidate] += weight * (6 - distance) * 1.35
            }
            // Small direct-frequency contribution prevents the sector score alone
            // from dominating all other evidence.
            scores[result] += weight * 0.30
        }

        // Blend recent frequency with wheel-neighbour evidence. A mild return-gap
        // term adds variety without claiming that an overdue number is "due".
        for (number in 0..36) {
            val freqWeight = frequency[number] * 0.22
            val gap = lastSeen[number].coerceAtMost(history.size)
            val gapWeight = kotlin.math.ln(1.0 + gap.toDouble()) * 0.08
            scores[number] += freqWeight + gapWeight
        }

        // Add small, explainable pattern weights. These are descriptive heuristics,
        // not probabilities; each roulette spin remains independent.
        val recent = history.take(8)
        val wheelIndex = { n: Int -> wheel.indexOf(n) }

        // FLOW: if the last few results cluster in one wheel neighbourhood,
        // gently favour that observed neighbourhood for the pattern display/rank.
        if (recent.size >= 3) {
            val anchor = recent.first()
            val anchorIndex = wheelIndex(anchor)
            val clustered = recent.take(4).count { n ->
                val d = abs(wheelIndex(n) - anchorIndex)
                minOf(d, wheel.size - d) <= 5
            }
            if (clustered >= 3) {
                for (offset in -5..5) {
                    val n = wheel[(anchorIndex + offset + wheel.size) % wheel.size]
                    scores[n] += (6 - abs(offset)) * 0.12
                }
            }
        }

        // FAST BREAK: when the recent flow changes wheel sector, mark the new
        // side as a break; do not manufacture a new spin from a changed OCR row.
        if (recent.size >= 4) {
            val anchorIndex = wheelIndex(recent.first())
            val previousIndex = wheelIndex(recent[1])
            val distance = abs(anchorIndex - previousIndex).let { minOf(it, wheel.size - it) }
            if (distance >= 9) {
                for (offset in -2..2) {
                    val n = wheel[(anchorIndex + offset + wheel.size) % wheel.size]
                    scores[n] += 0.18
                }
            }
        }

        // BRACKET: neighbouring pockets around the latest confirmed result.
        val last = recent.firstOrNull()
        if (last != null) {
            val i = wheelIndex(last)
            for (offset in -2..2) {
                val n = wheel[(i + offset + wheel.size) % wheel.size]
                scores[n] += if (offset == 0) 0.0 else 0.10 * (3 - abs(offset))
            }
        }

        // ZIGZAG: detect alternating red/black parity as a simple display signal;
        // the ranking weight is intentionally small and never treated as certainty.
        if (recent.size >= 4) {
            val alternating = (1 until 4).all { i ->
                (recent[i] % 2) != (recent[i - 1] % 2) && recent[i] != 0 && recent[i - 1] != 0
            }
            if (alternating) {
                val expectedParity = 1 - (recent.first() % 2)
                for (n in 1..36) if (n % 2 == expectedParity) scores[n] += 0.08
            }
        }

        return (0..36).filter { it !in excludedNumbers }.sortedWith(
            compareByDescending<Int> { scores[it] }
                .thenByDescending { frequency[it] }
                .thenBy { it }
        ).take(4)
    }

    private fun chooseHistoryBasedGuess(): Int = rankHistoryGuesses().firstOrNull() ?: 0

    // Standard European single-zero wheel sectors. Counts describe past data only;
    // they do not imply that a sector is more likely on the next independent spin.
    private fun updateStrategyPanel() {
        val wheel = listOf(
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13,
            36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14,
            31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
        )
        val voisins = setOf(22, 18, 29, 7, 28, 12, 35, 3, 26, 0, 32, 15, 19, 4, 21, 2, 25)
        val tiers = setOf(27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33)
        val orphelins = setOf(1, 20, 14, 31, 9, 17, 34, 6)
        val sample = recentHistory.toList().take(100)
        fun count(group: Set<Int>) = sample.count { it in group }
        fun topNumbers(descending: Boolean): String {
            val counts = (0..36).associateWith { n -> sample.count { it == n } }
            val ordered = counts.entries.filter { it.value > 0 }.let { entries ->
                if (descending) entries.sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
                else entries.sortedWith(compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            }
            return if (ordered.isEmpty()) "—" else ordered.take(3).joinToString("  ") { "${it.key}(${it.value})" }
        }
        val finals = (0..9).associateWith { d -> sample.count { it % 10 == d } }
            .entries.sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            .take(3).joinToString("  ") { "${it.key}(${it.value})" }
        val last = sample.firstOrNull()
        val neighbours = if (last != null) {
            val i = wheel.indexOf(last)
            if (i >= 0) "${wheel[(i - 2 + 37) % 37]} · ${wheel[(i - 1 + 37) % 37]} · [$last] · ${wheel[(i + 1) % 37]} · ${wheel[(i + 2) % 37]}" else "—"
        } else "—"
        val total = sample.size.coerceAtLeast(1)
        val rankedPicks = rankHistoryGuesses().take(3).joinToString(" · ")
        val recent = sample.take(8)
        val flowText = if (recent.size >= 3) {
            val anchor = wheel.indexOf(recent.first())
            val cluster = recent.take(4).count { n ->
                val d = abs(wheel.indexOf(n) - anchor)
                minOf(d, 37 - d) <= 5
            }
            if (cluster >= 3) "ACTIVE • wheel-neighbour cluster" else "MIXED • no stable flow"
        } else "WAIT • need more results"
        val fastBreakText = if (recent.size >= 2) {
            val d = abs(wheel.indexOf(recent[0]) - wheel.indexOf(recent[1])).let { minOf(it, 37 - it) }
            if (d >= 9) "BREAK • sector jump observed" else "NO BREAK • nearby movement"
        } else "WAIT"
        val bracketText = recent.firstOrNull()?.let { n ->
            val i = wheel.indexOf(n)
            "${wheel[(i - 2 + 37) % 37]} · ${wheel[(i - 1 + 37) % 37]} · [$n] · ${wheel[(i + 1) % 37]} · ${wheel[(i + 2) % 37]}"
        } ?: "—"
        val zigzagText = if (recent.size >= 4 && (1 until 4).all { i ->
            recent[i] != 0 && recent[i - 1] != 0 && (recent[i] % 2) != (recent[i - 1] % 2)
        }) "ACTIVE • alternating parity" else "NOT ACTIVE"
        val details = "EUROPEAN WHEEL • ${sample.size} results\n" +
            "FLOW: $flowText\n" +
            "FAST BREAK: $fastBreakText\n" +
            "BRACKET: $bracketText\n" +
            "ZIGZAG: $zigzagText\n" +
            "Top strategy picks: $rankedPicks\n" +
            "Voisins du Zéro: ${count(voisins)} (${count(voisins) * 100 / total}%)\n" +
            "Tiers du Cylindre: ${count(tiers)} (${count(tiers) * 100 / total}%)\n" +
            "Orphelins: ${count(orphelins)} (${count(orphelins) * 100 / total}%)\n" +
            "Last result neighbours: $neighbours\n" +
            "Hot numbers: ${topNumbers(true)}\n" +
            "Low frequency: ${topNumbers(false)}\n" +
            "Finals: $finals\n" +
            "Note: past frequency only; no next-spin guarantee."
        android.os.Handler(mainLooper).post { strategyView?.text = details }
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(35, 20, 82), Color.rgb(22, 38, 105), Color.rgb(10, 14, 42))
            ).apply {
                shape = GradientDrawable.RECTANGLE
                setStroke(dp(2), Color.rgb(0, 225, 255))
            }
        }
        val heading = TextView(this).apply {
            text = "ROULETTE • INFO • V6.30"
            setTextColor(Color.WHITE)
            textSize = 7f
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener {
                strategyExpanded = !strategyExpanded
                strategyView?.visibility = if (strategyExpanded) View.VISIBLE else View.GONE
                val params = panelParams
                if (params != null) {
                    params.width = dp(if (strategyExpanded) 240 else 124)
                    params.height = dp(if (strategyExpanded) 330 else 112)
                    try { panel?.let { windowManager.updateViewLayout(it, params) } } catch (_: Exception) {}
                }
                (panel as? LinearLayout)?.background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.rgb(35, 20, 82), Color.rgb(22, 38, 105), Color.rgb(10, 14, 42))
                ).apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 0f
                    setStroke(dp(2), Color.rgb(0, 225, 255))
                }
                text = if (strategyExpanded) "ROULETTE • HIDE INFO" else "ROULETTE • INFO • V6.28"
                updateStrategyPanel()
            }
        }
        predictionView = TextView(this).apply {
            text = "--"
            setTextColor(Color.rgb(91, 255, 145))
            textSize = 27f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        alternatePredictionViews.clear()
        val alternateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        repeat(3) {
            val smallNumber = TextView(this).apply {
                text = "—"
                setTextColor(Color.rgb(205, 225, 255))
                textSize = 9f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                maxLines = 1
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(3).toFloat()
                    setColor(Color.rgb(27, 35, 76))
                    setStroke(dp(1), Color.rgb(70, 115, 190))
                }
            }
            alternatePredictionViews.add(smallNumber)
            alternateRow.addView(
                smallNumber,
                LinearLayout.LayoutParams(0, dp(17), 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                }
            )
        }
        statusView = TextView(this).apply {
            text = "STAR OFF"
            setTextColor(Color.WHITE)
            textSize = 7f
            gravity = Gravity.CENTER
            maxLines = 2
        }
        starButton = TextView(this).apply {
            text = "☆ STAR"
            setTextColor(Color.WHITE)
            textSize = 9f
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(7), dp(3), dp(7), dp(3))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 0f
                setColor(Color.rgb(44, 35, 110))
                setStroke(dp(1), Color.rgb(0, 225, 255))
            }
            setOnClickListener {
                scanActive = !scanActive
                pendingNumbers = emptyList()
                pendingRepeats = 0
                pendingExactRepeats = 0
                mismatchSnapshot = emptyList()
                mismatchRepeats = 0
                mismatchExactRepeats = 0
                mismatchFirstNumber = null
                mismatchFirstRepeats = 0
                // Foreground watcher attaches the capture surface only when
                // the 1xBet app is actually in front of the user.
                if (scanActive) {
                    lastWatcherStatus = null
                    startForegroundWatcher()
                    // Keep the last valid prediction visible while waiting
                    // for the next confirmed spin.
                    updatePrediction(lastPrediction)
                    updateStatus("গেম History খুঁজছি…")
                    text = "★ STAR ON"
                } else {
                    lastWatcherStatus = null
                    stopForegroundWatcher()
                    // Keep the last valid prediction visible while scanning is paused.
                    updatePrediction(lastPrediction)
                    updateStatus("SCAN PAUSED")
                    text = "☆ STAR OFF"
                }
            }
        }

        strategyView = TextView(this).apply {
            text = "European strategy details will appear after History is read."
            setTextColor(Color.WHITE)
            textSize = 9f
            gravity = Gravity.START
            setPadding(dp(8), dp(5), dp(8), dp(5))
            visibility = View.GONE
        }
        root.addView(heading, LinearLayout.LayoutParams(dp(82), dp(12)))
        root.addView(predictionView, LinearLayout.LayoutParams(dp(82), dp(34)))
        root.addView(alternateRow, LinearLayout.LayoutParams(dp(112), dp(19)))
        root.addView(statusView, LinearLayout.LayoutParams(dp(92), dp(18)))
        root.addView(starButton, LinearLayout.LayoutParams(dp(68), dp(22)))
        root.addView(strategyView, LinearLayout.LayoutParams(dp(224), dp(220)))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        panelParams = WindowManager.LayoutParams(
            dp(124),
            dp(112),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Keep the floating panel below the live History strip. The old
            // y=140px default covered the leftmost history cells on this game.
            x = 12
            y = 270
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val params = panelParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })

        try {
            windowManager.addView(root, panelParams)
            panel = root
            updateStrategyPanel()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun updatePrediction(number: Int?, alternatives: List<Int> = lastPredictionAlternates) {
        android.os.Handler(mainLooper).post {
            predictionView?.text = number?.toString() ?: "--"
            alternatePredictionViews.forEachIndexed { index, view ->
                view.text = alternatives.getOrNull(index)?.toString() ?: "—"
            }
        }
    }

    private fun updateStatus(message: String) {
        android.os.Handler(mainLooper).post {
            statusView?.text = message
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Roulette OCR capture",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scanActive = false
        stopForegroundWatcher()
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
