# Immersive Roulette AI

Android native floating overlay + screen capture OCR prototype.

## Important package identity\nThis project uses the distinct application ID `com.example.immersiverouletteai`, so it installs as a separate app rather than updating an older `com.example.liveroulette` APK.\n\n## Build
GitHub Actions runs `gradle assembleDebug` on every push to `main` and on manual workflow dispatch. Download the `ImmersiveRouletteAI-debug` artifact from the workflow run.

## First launch
1. Open the app.
2. Grant Display over other apps permission.
3. Tap START FLOATING PANEL.
4. Approve Android screen capture.
5. Open a roulette screen and tap STAR ON in the floating panel.

## Important OCR limitation
The included ML Kit OCR is a general text recognizer. The current roulette-screen check looks for roulette-related text and multiple 0–36 values; it then uses the last recognized number as a candidate. This is only a prototype: it can select a table number rather than the actual latest result, and must be calibrated to the exact game screen before real use. OCR text order varies by site/layout, so this is a prototype and must be calibrated against screenshots of the exact roulette game's result-history area before treating detected numbers as accurate.

Roulette outcomes are random. The displayed number is only a simple historical-frequency heuristic, not a reliable prediction or betting advice.

STAR OFF prevents bitmap conversion and OCR analysis. Android's MediaProjection stream remains active while the capture service is running because the user-approved capture session is established at service start.


## Top history OCR update
The capture service now crops the top result-history strip (approximately 10.2%-13.2% of the captured screen height), reads number tokens, orders them left-to-right, and treats the leftmost token as the newest result. It requires three matching OCR snapshots before updating the prediction. This crop is tuned to the supplied roulette screenshot and may need adjustment if the game layout, orientation, or screen scaling changes.

The displayed next number is a frequency-based heuristic over the visible history, not a statistically reliable prediction. Roulette outcomes are random.
