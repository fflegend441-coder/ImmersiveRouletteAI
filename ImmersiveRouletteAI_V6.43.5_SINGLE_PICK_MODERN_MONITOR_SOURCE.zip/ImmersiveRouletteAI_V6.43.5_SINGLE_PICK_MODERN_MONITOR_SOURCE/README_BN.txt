ImmersiveRouletteAI V6.43.5 — Single Pick + Modern Live Monitor

Changes:
- Main app has only START and STOP controls.
- START requests overlay, Usage Access, and screen-capture permissions in sequence.
- After authorization, the foreground watcher waits for the installed 1xBet app and attaches capture only while it is foreground.
- Floating panel has no STAR/START control.
- Compact draggable panel displays one top-ranked history heuristic number only.
- Expanded monitor reports Live Capture, OCR, Camera Scene, Angle Calibration, Wheel Tracking, Ball Tracking, History, and Prediction Engine states.
- Alternative prediction UI and persisted alternative picks have been removed.
- Prediction is withheld until at least 12 confirmed history results are available.
- Displayed number is a history-based rank, not a measured probability or guaranteed next-spin prediction.
- Version: 6.43.5 / versionCode 54.

Validation:
- Run verification/check_source.py for static source assertions.
- CameraSceneDetector deterministic Kotlin test is included.
- Android APK build and physical-device 1xBet runtime validation must still be completed in a configured Android SDK environment.

Limitations:
- Roulette outcomes are independent; past results do not make a number more likely on the next spin.
- Wheel and ball tracking remain experimental image heuristics, not calibrated physical tracking.
- Camera Scene detects coarse luminance changes, not semantic camera-angle identity.
- OCR reliability depends on the visible history strip, resolution, overlays, and game layout.

Build: Open project root in Android Studio with Android SDK 35 and Java 17, or run gradle assembleDebug.
