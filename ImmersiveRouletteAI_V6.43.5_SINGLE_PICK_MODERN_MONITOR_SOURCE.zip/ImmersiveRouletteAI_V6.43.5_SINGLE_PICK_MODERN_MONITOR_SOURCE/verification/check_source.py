from pathlib import Path
import re

main = Path('app/src/main/java/com/example/liveroulette/MainActivity.kt').read_text()
service = Path('app/src/main/java/com/example/liveroulette/CaptureService.kt').read_text()
gradle = Path('app/build.gradle').read_text()
assert 'text = "START"' in main and 'text = "STOP"' in main
assert 'starButton' not in service and 'STAR ON' not in service and 'STAR OFF' not in service
assert 'ALTERNATIVES' not in service and 'alternatePredictionViews' not in service
assert 'TOP HISTORY RANK' in service
assert 'scanActive = true' in service and 'startForegroundWatcher()' in service
for feature in ('LIVE CAPTURE', 'OCR', 'CAMERA SCENE', 'ANGLE CALIBRATION', 'WHEEL TRACKING', 'BALL TRACKING', 'HISTORY', 'PREDICTION ENGINE'):
    assert feature in service, feature
assert "versionName '6.43.5'" in gradle and 'versionCode 54' in gradle
print('V6.43.5 source checks: PASS')
