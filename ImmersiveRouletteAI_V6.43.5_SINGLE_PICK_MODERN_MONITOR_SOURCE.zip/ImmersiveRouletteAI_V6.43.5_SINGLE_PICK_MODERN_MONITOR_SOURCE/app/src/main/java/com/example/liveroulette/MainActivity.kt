package com.example.liveroulette

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_OVERLAY = 4101
        private const val REQUEST_CAPTURE = 4102
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.example.liveroulette.STOP_CAPTURE"
    }

    private lateinit var projectionManager: MediaProjectionManager
    private var waitingForUsagePermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4103)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(10, 16, 29))
        }
        val title = TextView(this).apply {
            text = "IMMERSIVE AI"
            textSize = 25f
            setTextColor(android.graphics.Color.rgb(133, 196, 255))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Live Roulette Assistant"
            textSize = 14f
            setTextColor(android.graphics.Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        val startButton = Button(this).apply {
            text = "START"
            textSize = 18f
            setOnClickListener { startCaptureFlow() }
        }
        val stopButton = Button(this).apply {
            text = "STOP"
            textSize = 18f
            setOnClickListener {
                val stopIntent = Intent(this@MainActivity, CaptureService::class.java).apply { action = ACTION_STOP }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) stopService(stopIntent)
                else stopService(stopIntent)
                Toast.makeText(this@MainActivity, "Live scan stopped", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(startButton, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        layout.addView(stopButton, LinearLayout.LayoutParams(-1, 58))
        setContentView(layout)
    }

    private fun hasUsageAccess(): Boolean = try {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQUEST_OVERLAY
            )
            return
        }
        if (!hasUsageAccess()) {
            waitingForUsagePermission = true
            Toast.makeText(this, "1xBet auto-detection চালু করতে Usage Access অনুমতি দিন", Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            catch (_: Exception) { Toast.makeText(this, "Usage Access settings খোলা যায়নি", Toast.LENGTH_LONG).show() }
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    override fun onResume() {
        super.onResume()
        if (waitingForUsagePermission) {
            waitingForUsagePermission = false
            if (hasUsageAccess()) requestScreenCapture()
            else Toast.makeText(this, "Usage Access অনুমতি ছাড়া 1xBet auto-detection কাজ করবে না", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy result callback supports the current Android baseline")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startCaptureFlow()
            else Toast.makeText(this, "Floating Panel permission দেওয়া হয়নি", Toast.LENGTH_LONG).show()
            return
        }
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "Screen Capture permission দেওয়া হয়নি", Toast.LENGTH_LONG).show()
                return
            }
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            Toast.makeText(this, "Auto Scan ready • 1xBet খুলুন", Toast.LENGTH_SHORT).show()
        }
    }
}
