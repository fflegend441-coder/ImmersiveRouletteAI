Immersive Roulette AI V6.17 - Round-by-round Prediction Fix

এই সংস্করণে Prediction Lock ঠিক করা হয়েছে:
- প্রতিটি নতুন ফলাফল OCR-এ স্থিরভাবে নিশ্চিত হলে নতুন করে হিসাব হবে।
- আগের Main Prediction না এলেও পরের রাউন্ডে নতুন Main Prediction হবে।
- একই রাউন্ডে History অপরিবর্তিত থাকলে Prediction স্থির থাকবে।
- প্রতিটি নতুন রাউন্ডে ৩টি Alternative-ও নতুন করে হিসাব হবে।
- OCR History, European wheel order এবং আগের History সংরক্ষণ রাখা হয়েছে।

গুরুত্বপূর্ণ: Roulette-এর প্রতিটি spin স্বাধীন। History/wheel হিসাব কোনো নিশ্চিত জয়ের পূর্বাভাস নয়; এটি শুধু heuristic।

GitHub-এ Build করার নিয়ম:
1. এই ZIP-টি ফোন/কম্পিউটারে Extract করুন।
2. Extract করা ফোল্ডারের ভেতরের build.gradle, settings.gradle, gradle.properties, app/ এবং .github/
   ফাইল/ফোল্ডারগুলো repository-এর root-এ upload/replace করুন।
3. ZIP ফাইলটিকে repository-তে একা upload করবেন না। Workflow root থেকে `gradle assembleDebug` চালায়।
4. GitHub-এর Actions tab-এ Build Android APK সফল হলে Artifacts থেকে
   ImmersiveRouletteAI-v6.17-debug ডাউনলোড করুন।

APK output: app/build/outputs/apk/debug/app-debug.apk
