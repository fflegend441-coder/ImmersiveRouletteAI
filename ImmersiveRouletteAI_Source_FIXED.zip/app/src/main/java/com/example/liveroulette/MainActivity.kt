package com.example.liveroulette

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    companion object { private const val REQUEST_CAPTURE = 4102 }

    private var statusView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "IMMERSIVE ROULETTE AI"
            textSize = 22f
            setTextColor(0xFF34C759.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Start the floating panel, then open your roulette app.\n\nScreen capture is requested by Android. OCR runs only after you turn STAR ON."
            textSize = 15f
            setTextColor(0xFF333333.toInt())
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
        }
        statusView = TextView(this).apply {
            text = "Ready"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF444444.toInt())
        }
        val startButton = Button(this).apply {
            text = "START FLOATING PANEL"
            setOnClickListener { startCaptureFlow() }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 32, 24, 32)
            setBackgroundColor(0xFFF4F5F6.toInt())
            addView(title)
            addView(description)
            addView(startButton)
            addView(statusView)
        }
        setContentView(layout)
    }

    private fun startCaptureFlow() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            statusView?.text = "Allow 'Display over other apps', then return and tap START again."
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            @Suppress("DEPRECATION")
            startActivity(intent)
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }
    @Deprecated("Deprecated in Android, retained for compatibility with the screen-capture consent flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            statusView?.text = "Overlay started. Switch to roulette and tap STAR."
        } else {
            statusView?.text = "Screen-capture permission was not granted."
        }
    }
}
