Immersive Roulette AI V6.18 - Round Update / Prediction Refresh Fix

এই সংস্করণে:
- History row দুইটি স্থির OCR frame-এ নিশ্চিত হলে update গ্রহণ করে; আগের ৩-frame অপেক্ষা কমানো হয়েছে।
- স্বাভাবিক rolling overlap পাওয়া গেলে নতুন ফল শনাক্ত করে সঙ্গে সঙ্গে নতুন round calculation হয়।
- Overlap পাওয়া না গেলেও একই পরিবর্তিত row তিনবার স্থির থাকলে newest result দিয়ে history baseline update করে এবং নতুন calculation চালায়।
- এই fallback-এ আগের জমা history মুছে ফেলা হয় না।
- আগের prediction নম্বর wheel-এ আসা পর্যন্ত অপেক্ষা করার কোনো hit-condition নেই; নতুন ফল নিশ্চিত হলেই পুনরায় ranking হয়।
- একই round-এর history অপরিবর্তিত থাকলে prediction স্থির থাকে, যাতে একই round-এ বারবার flicker না করে।
- European wheel order, frequency, recency ও neighbour-sector heuristic রাখা হয়েছে।

গুরুত্বপূর্ণ: Roulette-এর প্রতিটি spin স্বাধীন। অতীতের ফল, wheel-neighbour বা frequency বিশ্লেষণ পরের ফল নিশ্চিতভাবে বলে না এবং জয়ের নিশ্চয়তা দেয় না।

GitHub Build:
1. ZIP Extract করুন।
2. Extract করা ফোল্ডারের ভেতরের build.gradle, settings.gradle, gradle.properties, app/ এবং .github/ ফাইল/ফোল্ডার repository root-এ upload/replace করুন।
3. ZIP ফাইলটি একা repository-তে upload করবেন না।
4. GitHub Actions-এ Android Build সফল হলে Artifacts থেকে APK ডাউনলোড করুন।

APK output: app/build/outputs/apk/debug/app-debug.apk

V6.22 - Per Round Prediction Refresh:
- প্রতিটি নতুন leftmost result দুইটি OCR read-এ নিশ্চিত হলেই নতুন round হিসেবে গ্রহণ করে।
- সম্পূর্ণ history row mismatch হলেও স্থির নতুন result শনাক্ত করে নতুন prediction calculation চালায়।
- আগের prediction নম্বর hit হওয়া পর্যন্ত অপেক্ষা করে না; প্রতি confirmed spin/round-এ নতুন prediction তৈরি করে।
- একই history row থাকলে prediction lock থাকে, যাতে একই round-এ অযথা prediction বদলায় না।
