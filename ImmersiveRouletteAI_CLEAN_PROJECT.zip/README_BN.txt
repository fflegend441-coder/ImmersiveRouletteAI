নতুন Roulette OCR Assistant Android project

ZIP-এর ভেতরের app, build.gradle, settings.gradle সরাসরি project root-এ আছে।

GitHub Actions workflow যদি ZIP extract করে `source` folder-এ build করে, ZIP-এর নাম রাখুন:
ImmersiveRouletteAI_OCR_HISTORY_FIXED.zip

গুরুত্বপূর্ণ:
1. GitHub-এ ZIP upload করার পর workflow চালান।
2. প্রথমবার চালু হলে ALLOW FLOATING PANEL দিন।
3. START FLOATING PANEL চাপুন এবং Android screen-capture permission দিন।
4. Roulette screen খোলার পর floating panel-এর STAR ON চাপুন।
5. STAR OFF থাকলে OCR বন্ধ থাকবে।

OCR বর্তমানে screen-এর সবচেয়ে বেশি roulette-number থাকা text line বেছে নেয়। আপনার roulette history strip-এর অবস্থান/রূপ আলাদা হলে একটি screenshot দেখে crop/row detection আরও নির্দিষ্ট করতে হবে।

Prediction কোনো নিশ্চিত ফল নয়। Roulette random; দেখানো সংখ্যা কেবল frequency-ভিত্তিক অনুমান।
