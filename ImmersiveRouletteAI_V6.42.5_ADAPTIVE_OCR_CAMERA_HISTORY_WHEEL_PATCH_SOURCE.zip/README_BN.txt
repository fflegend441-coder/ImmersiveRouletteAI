ImmersiveRouletteAI V6.42.4 — Video History OCR Fix

Changes:
- Replaced contrast-scored full-screen band selection with a normalized crop for the persistent 1xBet recent-results strip seen in the supplied video.
- The crop remains anchored to the top results row while the live broadcast changes between wheel, presenter and close-up camera shots.
- Preserved existing OCR token validation, multi-block row reconstruction, stable-snapshot confirmation, rolling-history overlap and newest-first normalization.
- Bumped Android version to 6.42.4 (versionCode 45) and updated GitHub Actions artifact name.

Important limitations:
- This source ZIP has not been built on an Android SDK/Gradle environment in this session.
- The video shows the game screen but not the floating panel, so end-to-end panel behavior cannot be verified from that video.
- Wheel/Ball tracking remains experimental. It is not a calibrated ball detector and cannot reliably predict roulette outcomes. Historical spins do not provide a dependable prediction of an independent next spin.

Build:
- Open the project root in Android Studio, or run `gradle assembleDebug` in an environment with Android SDK configured.


V6.42.5 পরিবর্তন:
- Adaptive History OCR: ভিডিওতে দেখা উপরের History strip-এর primary ROI (10.0%-13.9%) প্রথমে পড়ে।
- OCR ব্যর্থ হলে দুইটি কাছাকাছি fallback band (9.4%-14.5%, 10.6%-15.1%) পরীক্ষা করে।
- 10-15টি cell পাওয়া গেলেই snapshot stability ও rolling-overlap validation-এ পাঠায়; এক ফ্রেমের OCR ভুলকে Spin ধরে না।
- Camera scene-change monitor ও European wheel motion candidate tracker রাখা হয়েছে; এগুলো calibrated ball/landing detector নয়।
- Prediction নতুন Spin নিশ্চিত হলে তবেই পুনর্গণনা হয়। Roulette outcome স্বাধীন; এই heuristic rank কোনো জয়ের নিশ্চয়তা বা নির্ভরযোগ্য probability নয়।
- Android APK এবং বাস্তব 1xBet ডিভাইস পরীক্ষা আলাদাভাবে করতে হবে।
