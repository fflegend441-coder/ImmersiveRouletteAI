Immersive Roulette AI V6.16 - Source

গুরুত্বপূর্ণ: ZIP ফাইলটি GitHub repository-তে শুধু ZIP হিসেবে রেখে দিলে এই workflow build করবে না।
ZIP Extract করে ভেতরের build.gradle, settings.gradle, gradle.properties, app/ এবং .github/
ফোল্ডারগুলো repository-এর root-এ upload/replace করতে হবে।

GitHub Actions workflow: .github/workflows/android-apk.yml
এটি ZIP খোঁজে না; repository root থেকে সরাসরি `gradle assembleDebug` চালায়।
APK artifact: app/build/outputs/apk/debug/app-debug.apk
