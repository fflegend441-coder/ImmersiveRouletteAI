Immersive Roulette AI OCR — V5

V5 পরিবর্তন:
1. Floating panel আগের মতো 112dp রাখা হয়েছে, কিন্তু এখন চারকোনা rounded-rectangle; গোল নয়।
2. Panel থেকে STAR ON/OFF সরানো হয়েছে। START ON / STOP OFF মূল অ্যাপের ভিতরে।
3. START ON দিয়ে screen capture অনুমতি দিলে Live OCR স্বয়ংক্রিয়ভাবে চালু হয়; STOP OFF দিলে service, OCR ও panel বন্ধ হয়।
4. History বাম পাশে নতুন এবং ডান পাশে পুরোনো—এই ক্রম অনুসারে নতুন ফল শনাক্ত হয়।
5. সাময়িক OCR ভুলে History alignment নষ্ট না করতে শেষ সঠিক snapshot baseline হিসেবে রাখা হয়।
6. History overlap মিলিয়ে নতুন 1-4টি বামদিকের ফল শনাক্ত করা হয়; overlap-এ সর্বোচ্চ একটি OCR mismatch অনুমোদিত।
7. Prediction ইউরোপিয়ান wheel-এর নির্দিষ্ট ক্রমে সাম্প্রতিক ফলের পাশের sector-গুলো বিশ্লেষণ করে rank করে; visible History ও আগের prediction বাদ থাকে।
8. History অন্তত 12টি ফল না হলে prediction দেখায় না।

সতর্কতা: Roulette ফল random. Wheel-sector ranking একটি history heuristic মাত্র; কোনো জয়ের নিশ্চয়তা বা প্রকৃত probability edge নয়।

Build: project root-এ settings.gradle এবং app/ রয়েছে। GitHub Actions-এ Gradle 8.9 দিয়ে :app:assembleDebug চালানো যাবে।
