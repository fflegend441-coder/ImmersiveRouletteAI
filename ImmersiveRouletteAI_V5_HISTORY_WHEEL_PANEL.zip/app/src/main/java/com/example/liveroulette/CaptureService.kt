package com.example.liveroulette

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import kotlin.math.abs

class CaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "roulette_ocr_capture"
        private const val NOTIFICATION_ID = 7102
        private const val ACTION_STOP = MainActivity.ACTION_STOP
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var predictionView: TextView? = null
    private var statusView: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null

    @Volatile private var scanActive = false
    @Volatile private var processing = false
    private var lastOcrAt = 0L
    private var pendingNumbers: List<Int> = emptyList()
    private var pendingRepeats = 0
    // The game strip is newest-first (left to right) on the supplied game screen.
    private var previousNumbers: List<Int> = emptyList()
    private var visibleHistory: List<Int> = emptyList()
    private var lastPrediction: Int? = null
    private val recentHistory = ArrayDeque<Int>()
    private val numberRegex = Regex("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)")

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        if (projection == null) {
            val resultCode = intent?.getIntExtra(MainActivity.EXTRA_RESULT_CODE, 0) ?: 0
            val resultData = intent?.getParcelableExtra<Intent>(MainActivity.EXTRA_RESULT_DATA)
            if (resultCode == 0 || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            startProjection(resultCode, resultData)
            showPanel()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)
        scanActive = true

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        workerThread = HandlerThread("RouletteOCRWorker").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                try {
                    if (scanActive && !processing && System.currentTimeMillis() - lastOcrAt >= 500L) {
                        lastOcrAt = System.currentTimeMillis()
                        processImage(image)
                    }
                } finally {
                    image.close()
                }
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "RouletteOCRDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, workerHandler)
    }

    private fun processImage(image: Image) {
        val fullBitmap = imageToBitmap(image) ?: return
        val historyBitmap = cropHistoryStrip(fullBitmap)
        fullBitmap.recycle()
        if (historyBitmap == null) {
            updateStatus("History strip পাওয়া যায়নি")
            return
        }

        processing = true
        recognizer.process(InputImage.fromBitmap(historyBitmap, 0))
            .addOnSuccessListener { result ->
                if (!scanActive) return@addOnSuccessListener
                val numbers = extractHistoryNumbers(result)
                // The history strip normally contains about 14 values. Reject short
                // OCR fragments so betting-table numbers such as 1 or 2 are not used.
                if (numbers.size in 6..20) {
                    registerHistorySnapshot(numbers)
                } else {
                    pendingNumbers = emptyList()
                    pendingRepeats = 0
                    updateStatus("History row পড়া যাচ্ছে না • গেম স্ক্রিন দেখান")
                }
            }
            .addOnFailureListener {
                updateStatus("OCR পড়তে সমস্যা হচ্ছে")
            }
            .addOnCompleteListener {
                processing = false
                if (!historyBitmap.isRecycled) historyBitmap.recycle()
            }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        } catch (_: Exception) {
            null
        }
    }

    /**
     * The supplied game screenshot places its horizontal result-history strip
     * immediately below the top balance/header (roughly 9.5%-13.5% of screen height).
     * OCR is restricted to this strip, not the 0-36 betting grid below it.
     */
    private fun cropHistoryStrip(source: Bitmap): Bitmap? {
        return try {
            val top = (source.height * 0.095f).toInt().coerceIn(0, source.height - 1)
            val bottom = (source.height * 0.135f).toInt().coerceIn(top + 1, source.height)
            val strip = Bitmap.createBitmap(source, 0, top, source.width, bottom - top)
            val enlarged = Bitmap.createScaledBitmap(strip, strip.width * 2, strip.height * 2, true)
            strip.recycle()
            enlarged
        } catch (_: Exception) {
            null
        }
    }

    private fun extractHistoryNumbers(result: Text): List<Int> {
        val bestLine = result.textBlocks
            .flatMap { it.lines }
            .maxByOrNull { line -> numberRegex.findAll(line.text).count() }
            ?: return emptyList()

        // Use left-to-right element positions so the history order remains stable.
        val fromElements = bestLine.elements
            .sortedBy { it.boundingBox?.left ?: Int.MAX_VALUE }
            .flatMap { element -> numberRegex.findAll(element.text).mapNotNull { it.value.toIntOrNull() }.toList() }
            .filter { it in 0..36 }

        val parsed = if (fromElements.size >= 6) {
            fromElements
        } else {
            numberRegex.findAll(bestLine.text).mapNotNull { it.value.toIntOrNull() }
                .filter { it in 0..36 }.toList()
        }
        return parsed.take(20)
    }

    private fun registerHistorySnapshot(numbers: List<Int>) {
        if (numbers == pendingNumbers) {
            pendingRepeats++
        } else {
            pendingNumbers = numbers
            pendingRepeats = 1
        }
        if (pendingRepeats < 2) return

        if (previousNumbers.isEmpty()) {
            previousNumbers = numbers
            visibleHistory = numbers
            recentHistory.clear()
            numbers.forEach { recentHistory.addLast(it) }
            updatePredictionFromHistory("History loaded • ${numbers.size} results")
            return
        }

        if (numbers == previousNumbers) return

        val newResults = findNewResults(previousNumbers, numbers)
        visibleHistory = numbers

        if (newResults.isNotEmpty()) {
            // Leftmost values are newest. Insert the detected values in newest-first order.
            newResults.asReversed().forEach { recentHistory.addFirst(it) }
            while (recentHistory.size > 100) recentHistory.removeLast()
            previousNumbers = numbers
            updatePredictionFromHistory("নতুন ফল • ${recentHistory.size} results")
        } else {
            // Keep the last aligned snapshot. A temporary OCR misread must not
            // become the new baseline and cause the next real result to be lost.
            updateStatus("History মিলছে না • আবার পড়ছি")
        }
    }

    /** Find new leftmost values by matching the shifted history overlap. */
    private fun findNewResults(old: List<Int>, current: List<Int>): List<Int> {
        if (old.isEmpty() || current.isEmpty()) return emptyList()
        var bestShift = 0
        var bestMatches = 0
        var bestOverlap = 0
        val maxShift = minOf(4, current.size - 6)
        if (maxShift < 1) return emptyList()

        // New results enter on the LEFT. Therefore old[0] aligns with
        // current[shift], not with current[0]. Allow one OCR character/value
        // error, but require a long matching overlap to avoid false rounds.
        for (shift in 1..maxShift) {
            val overlap = minOf(old.size, current.size - shift)
            if (overlap < 6) continue
            val matches = (0 until overlap).count { index ->
                old[index] == current[index + shift]
            }
            if (matches > bestMatches) {
                bestShift = shift
                bestMatches = matches
                bestOverlap = overlap
            }
        }

        val requiredMatches = maxOf(6, bestOverlap - 1)
        return if (bestShift > 0 && bestMatches >= requiredMatches) {
            current.take(bestShift)
        } else {
            emptyList()
        }
    }

    private fun updatePredictionFromHistory(status: String) {
        // Do not manufacture a guess from a tiny sample. The visible history row
        // normally supplies enough results immediately after OCR stabilizes.
        if (recentHistory.size < 12) {
            lastPrediction = null
            updatePrediction(null)
            updateStatus("আরও History দরকার • ${recentHistory.size}/12")
            return
        }
        val next = chooseHistoryBasedGuess()
        lastPrediction = next
        updatePrediction(next)
        updateStatus("$status • History বিশ্লেষণ সম্পন্ন")
    }

    /**
     * Rank unseen candidates using nearby sectors on the European wheel.
     * This is a transparent history heuristic, not a probability guarantee.
     */
    private fun chooseHistoryBasedGuess(): Int {
        val wheel = listOf(
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13,
            36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14,
            31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
        )
        val history = recentHistory.toList().take(60) // newest first
        val excluded = visibleHistory.toSet() + listOfNotNull(lastPrediction)
        val candidates = (0..36).filter { it !in excluded }
        if (candidates.isEmpty()) return (0..36).firstOrNull { it != lastPrediction } ?: 0

        // Rank candidates by nearby European-wheel sectors seen in recent results.
        // Recent spins carry more weight; this is a history heuristic, not a guarantee.
        val scores = DoubleArray(37)
        history.forEachIndexed { historyIndex, result ->
            val wheelIndex = wheel.indexOf(result)
            if (wheelIndex < 0) return@forEachIndexed
            val recencyWeight = (history.size - historyIndex).toDouble() / history.size.coerceAtLeast(1)
            for (offset in -4..4) {
                val distance = kotlin.math.abs(offset)
                val candidate = wheel[(wheelIndex + offset + wheel.size) % wheel.size]
                if (candidate in candidates) {
                    val sectorWeight = (5 - distance).toDouble()
                    scores[candidate] += recencyWeight * sectorWeight
                }
            }
        }

        return candidates.maxWithOrNull(
            compareBy<Int> { scores[it] }.thenBy { -it }
        ) ?: candidates.first()
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(6), dp(7), dp(6))
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(16, 42, 56), Color.rgb(22, 105, 91), Color.rgb(10, 31, 43))
            ).apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setStroke(dp(2), Color.rgb(75, 230, 177))
            }
        }
        val heading = TextView(this).apply {
            text = "ROULETTE LIVE"
            setTextColor(Color.WHITE)
            textSize = 7f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(1))
        }
        predictionView = TextView(this).apply {
            text = "--"
            setTextColor(Color.rgb(91, 255, 145))
            textSize = 30f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
        }
        statusView = TextView(this).apply {
            text = "LIVE SCAN ON"
            setTextColor(Color.rgb(225, 245, 240))
            textSize = 8f
            gravity = Gravity.CENTER
            maxLines = 2
        }

        root.addView(heading, LinearLayout.LayoutParams(dp(96), dp(15)))
        root.addView(predictionView, LinearLayout.LayoutParams(dp(96), dp(48)))
        root.addView(statusView, LinearLayout.LayoutParams(dp(96), dp(22)))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val panelSize = dp(112) // same size as V4
        panelParams = WindowManager.LayoutParams(
            panelSize,
            panelSize,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 12
            y = 140
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val params = panelParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })

        try {
            windowManager.addView(root, panelParams)
            panel = root
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun updatePrediction(number: Int?) {
        android.os.Handler(mainLooper).post {
            predictionView?.text = number?.toString() ?: "--"
        }
    }

    private fun updateStatus(message: String) {
        android.os.Handler(mainLooper).post {
            statusView?.text = if (message.length > 22) message.take(22) else message
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Roulette OCR Assistant")
                .setContentText("Screen capture service is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Roulette OCR capture",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scanActive = false
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
