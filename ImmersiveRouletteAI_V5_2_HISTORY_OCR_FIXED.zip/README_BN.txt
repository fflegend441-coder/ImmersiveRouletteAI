Immersive Roulette OCR Assistant — V5.2

V5.2 history corrections:
1. OCR no longer assumes that the history row is in a fixed top-screen crop. It reads the complete captured frame and selects the most number-dense horizontal OCR line containing 6–20 valid roulette values; ties prefer the wider, higher line.
2. History snapshots can stabilize across two consecutive reads even when one OCR token differs, reducing the chance that a tiny OCR fluctuation prevents all history updates.
3. New results are expected on the LEFT. The matcher compares the old row with the shifted current row using sequence edit distance, tolerating up to two OCR token errors while requiring at least 82% similarity. Ambiguous alignments are rejected rather than guessed.
4. The panel status is no longer forcibly truncated to 22 characters, and it can display up to three lines.
5. European wheel ranking remains a heuristic only. Independent roulette spins are random; history and wheel sectors cannot guarantee or reliably predict the next result.

Build: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, compileSdk 35, targetSdk 34. GitHub Actions can build :app:assembleDebug with Gradle 8.9.
